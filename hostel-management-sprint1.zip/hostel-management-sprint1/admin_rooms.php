<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

$rooms = $pdo->query('SELECT * FROM rooms ORDER BY block, room_no')->fetchAll();

$pageTitle = 'Rooms';
require 'includes/header.php';
?>

<?php
hms_page_head(
    'Rooms',
    count($rooms) . ' room' . (count($rooms) === 1 ? '' : 's') . ' across the hostel',
    '<a href="admin_room_form.php" class="btn btn-primary btn-sm">' . icon('plus') . ' Add Room</a>'
);
?>

<div class="hms-card" data-hms-table>
<?php if (!$rooms): ?>
  <?php hms_empty('building', 'No rooms yet', 'Add your first room to start allocating beds.'); ?>
<?php else: ?>
  <div class="hms-table-toolbar">
    <div class="hms-table-search"><?= icon('search') ?><input type="text" data-hms-search placeholder="Search by room, block, or floor"></div>
    <div class="hms-table-meta" data-hms-count></div>
  </div>
  <div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
      <thead>
        <tr>
          <th>Room No</th><th>Block</th><th>Floor</th><th>Capacity</th>
          <th>Occupied</th><th>Available</th><th>Status</th><th>Actions</th>
        </tr>
      </thead>
      <tbody data-hms-rows>
        <?php foreach ($rooms as $r):
          $available = $r['capacity'] - $r['occupied_beds'];
          $full = $available <= 0;
          $status = $full ? 'Full' : ($r['occupied_beds'] > 0 ? 'Partially Occupied' : 'Vacant');
        ?>
          <tr data-row>
            <td><span class="door-plate"><?= e($r['room_no']) ?></span></td>
            <td><?= e($r['block']) ?></td>
            <td><?= e($r['floor']) ?></td>
            <td><?= (int) $r['capacity'] ?></td>
            <td><?= (int) $r['occupied_beds'] ?></td>
            <td><?= (int) $available ?></td>
            <td><?= hms_status_badge($status) ?></td>
            <td class="text-nowrap">
              <a href="admin_room_manage.php?id=<?= (int) $r['room_id'] ?>" class="btn btn-sm btn-primary">Manage</a>
              <a href="admin_room_form.php?id=<?= (int) $r['room_id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
              <form action="admin_room_delete.php" method="post" class="d-inline"
                    data-confirm data-confirm-title="Delete this room?"
                    data-confirm-text="Room <?= e($r['room_no']) ?> will be removed permanently. This cannot be undone.">
                <?= csrf_field() ?>
                <input type="hidden" name="room_id" value="<?= (int) $r['room_id'] ?>">
                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="hms-pagination" data-hms-pagination data-page-size="8"></div>
<?php endif; ?>
</div>

<?php require 'includes/footer.php'; ?>
