<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_login();

$isAdmin = $_SESSION['role'] === 'admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$isAdmin) {
        redirect('notices.php');
    }
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $title = trim($_POST['title'] ?? '');
        $body  = trim($_POST['body'] ?? '');
        if ($title === '' || $body === '') {
            set_flash('error', 'Both title and message are required.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO notices (title, body, posted_by) VALUES (?, ?, ?)');
            $stmt->execute([$title, $body, $_SESSION['user_id']]);
            set_flash('success', 'Notice posted.');
        }
    } elseif ($action === 'delete') {
        $id = (int) ($_POST['notice_id'] ?? 0);
        $pdo->prepare('DELETE FROM notices WHERE notice_id = ?')->execute([$id]);
        set_flash('success', 'Notice removed.');
    }

    redirect('notices.php');
}

$notices = $pdo->query('SELECT * FROM notices ORDER BY created_at DESC')->fetchAll();

$pageTitle = 'Notices';
require 'includes/header.php';
?>

<?php hms_page_head('Notices', count($notices) . ' announcement' . (count($notices) === 1 ? '' : 's') . ' for the whole hostel'); ?>

<?php if ($isAdmin): ?>
  <div class="hms-card hms-card-pad hms-form-card mb-4">
    <div class="hms-section-title"><h5><?= icon('notices') ?> Post a Notice</h5></div>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="add">
      <div class="mb-3">
        <label class="form-label">Title</label>
        <input type="text" name="title" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Message</label>
        <textarea name="body" class="form-control" rows="3" required></textarea>
      </div>
      <button type="submit" class="btn btn-primary"><?= icon('plus') ?> Post Notice</button>
    </form>
  </div>
<?php endif; ?>

<?php if (!$notices): ?>
  <div class="hms-card hms-card-pad">
    <?php hms_empty('notices', 'No notices posted yet', 'Announcements will show up here as soon as one is posted.'); ?>
  </div>
<?php endif; ?>

<?php foreach ($notices as $n): ?>
  <div class="hms-card hms-card-pad mb-3">
    <div class="d-flex justify-content-between flex-wrap gap-2">
      <strong><?= e($n['title']) ?></strong>
      <?php if ($isAdmin): ?>
        <form method="post" data-confirm data-confirm-title="Remove this notice?"
              data-confirm-text="&ldquo;<?= e($n['title']) ?>&rdquo; will no longer be visible to anyone.">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="notice_id" value="<?= (int) $n['notice_id'] ?>">
          <button type="submit" class="btn btn-sm btn-outline-danger">Remove</button>
        </form>
      <?php endif; ?>
    </div>
    <p class="mb-1 mt-2"><?= nl2br(e($n['body'])) ?></p>
    <div style="color:var(--h-text-dim);font-size:0.78rem;"><?= e($n['created_at']) ?></div>
  </div>
<?php endforeach; ?>

<?php require 'includes/footer.php'; ?>
