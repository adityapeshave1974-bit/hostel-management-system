<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    // Simple math CAPTCHA — no external service/API key needed, but it
    // stops basic scripted login attempts. Answer is checked against the
    // numbers we generated when the form was displayed (stored in session).
    $expectedCaptcha = (int) ($_SESSION['captcha_a'] ?? 0) + (int) ($_SESSION['captcha_b'] ?? 0);
    $givenCaptcha    = (int) ($_POST['captcha_answer'] ?? -1);
    unset($_SESSION['captcha_a'], $_SESSION['captcha_b']); // always issue a fresh one next time

    if ($givenCaptcha !== $expectedCaptcha) {
        set_flash('error', 'That verification answer was incorrect. Please try again.');
        redirect('login.php');
    }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        set_flash('error', 'Please enter both username and password.');
        redirect('login.php');
    }

    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $account = $stmt->fetch();

    if ($account && password_verify($password, $account['password'])) {
        $status = $account['status'] ?? 'approved';

        if ($status === 'pending') {
            set_flash('error', 'Your account is still awaiting warden approval. Please check back soon.');
            redirect('login.php');
        }
        if ($status === 'rejected') {
            set_flash('error', 'Your registration request was not approved. Contact the hostel administrator for help.');
            redirect('login.php');
        }

        session_regenerate_id(true);
        $_SESSION['user_id']    = $account['id'];
        $_SESSION['username']   = $account['username'];
        $_SESSION['role']       = $account['role'];
        $_SESSION['full_name']  = $account['full_name'];
        $_SESSION['student_id'] = $account['student_id'];
        redirect('dashboard.php');
    }

    set_flash('error', 'Invalid username or password.');
    redirect('login.php');
}

// Fresh CAPTCHA numbers for this render.
$_SESSION['captcha_a'] = random_int(1, 9);
$_SESSION['captcha_b'] = random_int(1, 9);

$pageTitle = 'Login';
require 'includes/header.php';
$flash = get_flash();

// Facts, reviews, and contact info live in includes/site_content.php so
// there's one place to edit them (used by both login.php and register.php).
require 'includes/site_content.php';
$facts = $HOSTEL_FACTS;
$reviews = array_map(static function ($r) {
    return ['name' => $r['name'], 'stars' => $r['rating'], 'quote' => $r['quote']];
}, $HOSTEL_REVIEWS);
$gallery = $HOSTEL_GALLERY;
?>

<div class="auth-hero" style="background-image:url('assets/images/hostel.jpg');">
  <div class="auth-hero-overlay"></div>

  <div class="auth-hero-content">
    <div class="auth-hero-brand reveal">
      <div class="auth-visual-brand">Bam Bir Hostel</div>
      <p class="auth-visual-tag">Home away from home &mdash; managed simply.</p>
    </div>

    <div class="auth-fact reveal" id="authFact" style="--reveal-delay:0.1s;">
      <span class="dot"></span><span id="authFactText"><?= e($facts[0]) ?></span>
    </div>

    <div class="auth-glass-card reveal" style="--reveal-delay:0.15s;">
      <h1 class="auth-title">Welcome back</h1>
      <p class="auth-subtitle">Sign in to your account</p>

      <?php if ($flash): $cls = $flash['type'] === 'error' ? 'danger' : $flash['type']; ?>
        <div class="alert-banner alert-banner-<?= e($cls) ?>"><?= e($flash['message']) ?></div>
      <?php endif; ?>

      <form method="post" novalidate>
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" required autofocus>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>

        <div class="captcha-box">
          <label class="form-label">&#128737;&#65039; Quick check &mdash; what is <?= (int) $_SESSION['captcha_a'] ?> + <?= (int) $_SESSION['captcha_b'] ?>?</label>
          <input type="text" inputmode="numeric" name="captcha_answer" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Login</button>
      </form>
      <p class="text-center mt-3 mb-0" style="color:var(--text-muted);">
        Student? <a href="register.php">Create an account</a>
      </p>
    </div>

    <div class="auth-contact reveal">
      Need help booking? Contact <strong><?= e(CONTACT_NAME) ?></strong> &mdash;
      <a href="tel:<?= e(str_replace(' ', '', CONTACT_PHONE)) ?>"><?= e(CONTACT_PHONE) ?></a>
    </div>

    <div class="auth-panel reveal">
      <div class="auth-panel-label">What guests say</div>
      <div class="auth-reviews" data-reveal-stagger>
        <?php foreach ($reviews as $r): ?>
          <div class="auth-review reveal">
            <div class="stars"><?= str_repeat('&#9733;', $r['stars']) . str_repeat('&#9734;', 5 - $r['stars']) ?></div>
            <p class="quote">&ldquo;<?= e($r['quote']) ?>&rdquo;</p>
            <div class="who">&mdash; <?= e($r['name']) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="auth-panel reveal">
      <div class="auth-panel-label">Take a look inside</div>
      <div class="auth-gallery" data-reveal-stagger>
        <?php foreach ($gallery as $g): ?>
          <figure class="auth-gallery-item reveal">
            <img src="<?= e($g['src']) ?>" alt="<?= e($g['caption']) ?>" loading="lazy">
            <figcaption><?= e($g['caption']) ?></figcaption>
          </figure>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="auth-panel reveal">
      <div class="auth-find-us">
        <div class="auth-find-us-head">
          <?= icon('map-pin') ?>
          <span>How students find us</span>
        </div>
        <div class="auth-map-embed">
          <iframe
            src="<?= e(MAP_EMBED_URL) ?>"
            width="100%" height="100%" style="border:0;"
            allowfullscreen loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
            title="Bam Bir Hostel location on Google Maps"></iframe>
        </div>
        <div class="auth-map-footer">
          <span class="auth-map-address"><?= e(MAP_ADDRESS) ?></span>
          <a href="<?= e(MAP_LINK_URL) ?>" target="_blank" rel="noopener" class="auth-map-link">
            Open in Google Maps <?= icon('external') ?>
          </a>
        </div>
      </div>

      <?php if (!empty($SOCIAL_LINKS)): ?>
        <div class="auth-panel-label auth-panel-label-social">Follow us</div>
        <div class="auth-social-row">
          <?php foreach ($SOCIAL_LINKS as $s): if (empty($s['url'])) continue; ?>
            <a href="<?= e($s['url']) ?>" target="_blank" rel="noopener" class="auth-social-btn" aria-label="<?= e($s['name']) ?>">
              <?= icon($s['icon']) ?>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
(function () {
  var facts = <?= json_encode($facts) ?>;
  var el = document.getElementById('authFactText');
  if (!el) return;
  var i = 0;
  setInterval(function () {
    i = (i + 1) % facts.length;
    el.style.opacity = 0;
    setTimeout(function () {
      el.textContent = facts[i];
      el.style.opacity = 1;
    }, 250);
  }, 3500);
})();
</script>

<?php require 'includes/footer.php'; ?>
