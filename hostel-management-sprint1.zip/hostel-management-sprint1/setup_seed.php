<?php
// Run this file ONCE in your browser after importing sql/schema.sql, to
// create demo logins for all three roles. Delete this file afterwards —
// it should never remain on a live server.
require 'config/database.php';

function seed_login(PDO $pdo, string $username, string $password, string $role, string $fullName, ?int $studentId = null): string
{
    $exists = $pdo->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
    $exists->execute([$username]);
    if ($exists->fetch()) {
        return "Skipped: '$username' already exists.";
    }
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (username, password, role, full_name, student_id) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$username, $hash, $role, $fullName, $studentId]);
    return "Created '$username' ($role) with password '$password'.";
}

$results = [];
$results[] = seed_login($pdo, 'admin', 'Admin@123', 'admin', 'Hostel Administrator');
$results[] = seed_login($pdo, 'warden1', 'Warden@123', 'warden', 'Hostel Warden');

// Demo student — gives you something to click into immediately instead of
// having to add a student and register an account by hand before you can
// see the student view.
$studentUserExists = $pdo->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
$studentUserExists->execute(['student1']);

if ($studentUserExists->fetch()) {
    $results[] = "Skipped: 'student1' already exists.";
} else {
    $pdo->beginTransaction();

    $insStudent = $pdo->prepare(
        'INSERT INTO students (name, gender, department, year, mobile, guardian_name, guardian_mobile)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    $insStudent->execute(['Aditi Sharma', 'Female', 'Computer Science', 2, '9876543210', 'Rajesh Sharma', '9876500000']);
    $studentId = (int) $pdo->lastInsertId();

    $insUser = $pdo->prepare(
        'INSERT INTO users (username, password, role, full_name, student_id) VALUES (?, ?, ?, ?, ?)'
    );
    $insUser->execute(['student1', password_hash('Student@123', PASSWORD_DEFAULT), 'student', 'Aditi Sharma', $studentId]);

    // Give them a demo room too, so the student dashboard isn't empty on first login.
    $roomExists = $pdo->prepare('SELECT room_id FROM rooms WHERE room_no = ?');
    $roomExists->execute(['A-101']);
    $room = $roomExists->fetch();

    if (!$room) {
        $insRoom = $pdo->prepare('INSERT INTO rooms (room_no, block, floor, capacity) VALUES (?, ?, ?, ?)');
        $insRoom->execute(['A-101', 'A', '1', 2]);
        $roomId = (int) $pdo->lastInsertId();
    } else {
        $roomId = (int) $room['room_id'];
    }

    $insAlloc = $pdo->prepare('INSERT INTO room_allocations (student_id, room_id, allocated_date) VALUES (?, ?, CURDATE())');
    $insAlloc->execute([$studentId, $roomId]);
    $pdo->prepare('UPDATE rooms SET occupied_beds = occupied_beds + 1 WHERE room_id = ?')->execute([$roomId]);

    $pdo->commit();
    $results[] = "Created student record 'Aditi Sharma' (#$studentId), login 'student1' / 'Student@123', allocated to Room A-101.";
}
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Seed Accounts</title></head>
<body style="font-family: sans-serif; max-width: 640px; margin: 60px auto;">
<h2>Seed Result</h2>
<ul>
<?php foreach ($results as $r): ?>
  <li><?= htmlspecialchars($r) ?></li>
<?php endforeach; ?>
</ul>
<p><strong>Important:</strong> delete <code>setup_seed.php</code> from the server now.</p>
<p><a href="login.php">Go to login</a></p>
</body></html>
