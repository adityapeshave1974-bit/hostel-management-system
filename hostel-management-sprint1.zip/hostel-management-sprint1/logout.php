<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';

$_SESSION = [];
session_destroy();
redirect('login.php');
