<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin_rooms.php');
}
verify_csrf();

$id = (int) ($_POST['room_id'] ?? 0);

$stmt = $pdo->prepare('SELECT occupied_beds FROM rooms WHERE room_id = ?');
$stmt->execute([$id]);
$room = $stmt->fetch();

if (!$room) {
    set_flash('error', 'Room not found.');
} elseif ((int) $room['occupied_beds'] > 0) {
    set_flash('error', 'This room still has occupants. Vacate everyone before deleting it.');
} else {
    $stmt = $pdo->prepare('DELETE FROM rooms WHERE room_id = ?');
    $stmt->execute([$id]);
    set_flash('success', 'Room deleted.');
}

redirect('admin_rooms.php');
