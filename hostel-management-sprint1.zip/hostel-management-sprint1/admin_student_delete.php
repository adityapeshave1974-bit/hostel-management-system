<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin_students.php');
}
verify_csrf();

$id = (int) ($_POST['student_id'] ?? 0);

$stmt = $pdo->prepare(
    "SELECT COUNT(*) FROM room_allocations WHERE student_id = ? AND vacated_date IS NULL"
);
$stmt->execute([$id]);
$hasActiveRoom = (int) $stmt->fetchColumn() > 0;

if ($hasActiveRoom) {
    set_flash('error', 'This student currently occupies a room. Vacate them from Room Management before deleting.');
} else {
    $stmt = $pdo->prepare('DELETE FROM students WHERE student_id = ?');
    $stmt->execute([$id]);
    set_flash('success', 'Student record deleted.');
}

redirect('admin_students.php');
