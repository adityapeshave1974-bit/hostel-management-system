<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('warden');

$rooms = $pdo->query('SELECT * FROM rooms ORDER BY block, room_no')->fetchAll();
$totalStudents = $pdo->query('SELECT COUNT(*) FROM students')->fetchColumn();
$pendingComplaints = (int) $pdo->query("SELECT COUNT(*) FROM complaints WHERE status='Pending'")->fetchColumn();
$pendingApprovals = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role='student' AND status='pending'")->fetchColumn();

$capacitySum  = array_sum(array_column($rooms, 'capacity'));
$occupiedSum  = array_sum(array_column($rooms, 'occupied_beds'));

$pageTitle = 'Warden Dashboard';
require 'includes/header.php';
?>

<div class="hms-page-head">
  <div>
    <h1 class="hms-page-title">Welcome back, <?= e(explode(' ', $_SESSION['full_name'])[0]) ?></h1>
    <p class="hms-page-subtitle">A quick look at rooms and open complaints across the hostel.</p>
  </div>
</div>

<div class="hms-stat-grid">
  <?= hms_stat('Total Students', (string) (int) $totalStudents, 'students') ?>
  <?= hms_stat('Total Rooms', (string) count($rooms), 'building', 'violet') ?>
  <?= hms_stat('Occupied Beds', (string) $occupiedSum, 'bed', 'danger') ?>
  <?= hms_stat('Pending Approvals', (string) $pendingApprovals, 'user-check', $pendingApprovals > 0 ? 'warning' : 'success') ?>
  <?= hms_stat('Pending Complaints', (string) $pendingComplaints, 'alert', $pendingComplaints > 0 ? 'warning' : 'success') ?>
</div>

<?php $occPct = $capacitySum > 0 ? ($occupiedSum / $capacitySum) * 100 : 0; ?>
<div class="hms-card hms-card-pad mb-3">
  <?= hms_progress('Overall bed occupancy', $occPct, round($occPct) . '% occupied', $occPct > 85 ? 'danger' : 'warning') ?>
</div>

<div class="hms-section-title"><h5><?= icon('building') ?> Room Occupancy Overview</h5></div>
<div class="hms-card" data-hms-table>
  <?php if (!$rooms): ?>
    <?php hms_empty('building', 'No rooms yet'); ?>
  <?php else: ?>
    <div class="hms-table-toolbar">
      <div class="hms-table-search"><?= icon('search') ?><input type="text" data-hms-search placeholder="Search by room or block"></div>
      <div class="hms-table-meta" data-hms-count></div>
    </div>
    <div class="table-responsive">
      <table class="table align-middle mb-0">
        <thead><tr><th>Room No</th><th>Block</th><th>Floor</th><th>Capacity</th><th>Occupied</th><th>Available</th></tr></thead>
        <tbody data-hms-rows>
          <?php foreach ($rooms as $r): ?>
            <tr data-row>
              <td><span class="door-plate"><?= e($r['room_no']) ?></span></td>
              <td><?= e($r['block']) ?></td>
              <td><?= e($r['floor']) ?></td>
              <td><?= (int) $r['capacity'] ?></td>
              <td><?= (int) $r['occupied_beds'] ?></td>
              <td><?= (int) ($r['capacity'] - $r['occupied_beds']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="hms-pagination" data-hms-pagination data-page-size="8"></div>
  <?php endif; ?>
</div>

<div class="hms-section-title" style="margin-top:1.5rem;"><h5><?= icon('bell') ?> Quick Actions</h5></div>
<div class="hms-tile-grid">
  <?= hms_tile('user-check', 'Registration Approvals', 'Review new student sign-ups and approve or reject each one.', 'warden_approvals.php', 'Review Requests') ?>
  <?= hms_tile('complaints', 'Complaints', 'Review and update the status of student complaints.', 'staff_complaints.php', 'Review Complaints') ?>
  <?= hms_tile('notices', 'Notices', 'Read hostel-wide announcements from the admin.', 'notices.php', 'View Notices') ?>
</div>

<?php require 'includes/footer.php'; ?>
