<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_login();

switch ($_SESSION['role']) {
    case 'admin':
        redirect('admin_dashboard.php');
    case 'warden':
        redirect('warden_dashboard.php');
    case 'student':
        redirect('student_dashboard.php');
    default:
        redirect('login.php');
}
