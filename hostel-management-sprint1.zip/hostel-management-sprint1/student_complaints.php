<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('student');

$studentId = $_SESSION['student_id'];
$stmt = $pdo->prepare('SELECT * FROM complaints WHERE student_id = ? ORDER BY created_at DESC');
$stmt->execute([$studentId]);
$complaints = $stmt->fetchAll();

$pageTitle = 'My Complaints';
require 'includes/header.php';
?>

<?php
hms_page_head(
    'My Complaints',
    count($complaints) . ' filed so far',
    '<a href="student_complaint_new.php" class="btn btn-primary btn-sm">' . icon('plus') . ' File a Complaint</a>'
);
?>

<?php if (!$complaints): ?>
  <div class="hms-card hms-card-pad">
    <?php hms_empty('complaints', "You haven't filed any complaints", 'Use the button above if something needs attention.'); ?>
  </div>
<?php endif; ?>

<?php foreach ($complaints as $c): ?>
  <div class="hms-card hms-card-pad mb-3">
    <div class="d-flex justify-content-between flex-wrap gap-2 mb-2">
      <strong><?= e($c['subject']) ?></strong>
      <?= hms_status_badge($c['status']) ?>
    </div>
    <p class="mb-2"><?= nl2br(e($c['description'])) ?></p>
    <div style="color:var(--h-text-dim);font-size:0.78rem;" class="mb-2">Filed <?= e($c['created_at']) ?></div>
    <?php if (!empty($c['response'])): ?>
      <div class="alert-banner alert-banner-info mb-0">
        <strong>Response:</strong> <?= nl2br(e($c['response'])) ?>
      </div>
    <?php endif; ?>
  </div>
<?php endforeach; ?>

<?php require 'includes/footer.php'; ?>
