<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

$q = trim($_GET['q'] ?? '');

if ($q !== '') {
    $stmt = $pdo->prepare(
        "SELECT * FROM students
         WHERE name LIKE ? OR department LIKE ? OR student_id LIKE ? OR mobile LIKE ?
         ORDER BY student_id DESC"
    );
    $like = "%$q%";
    $stmt->execute([$like, $like, $like, $like]);
} else {
    $stmt = $pdo->query('SELECT * FROM students ORDER BY student_id DESC');
}
$students = $stmt->fetchAll();

$pageTitle = 'Students';
require 'includes/header.php';
?>

<?php
hms_page_head(
    'Students',
    count($students) . ' record' . (count($students) === 1 ? '' : 's') . ' on file',
    '<a href="admin_student_form.php" class="btn btn-primary btn-sm">' . icon('plus') . ' Add Student</a>'
);
?>

<form method="get" class="mb-3">
  <div class="hms-table-search" style="max-width:420px;">
    <?= icon('search') ?>
    <input type="text" name="q" placeholder="Search by name, department, mobile, or ID" value="<?= e($q) ?>">
  </div>
</form>
<?php if ($q !== ''): ?>
  <div class="mb-3"><a href="admin_students.php" class="btn btn-outline-secondary btn-sm">Clear search</a></div>
<?php endif; ?>

<div class="hms-card" data-hms-table>
<?php if (!$students): ?>
  <?php hms_empty('students', $q !== '' ? 'No matching students' : 'No students yet', $q !== '' ? 'Try a different search term.' : 'Add your first student to get started.'); ?>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
      <thead>
        <tr>
          <th>ID</th><th>Name</th><th>Gender</th><th>Department</th><th>Year</th>
          <th>Mobile</th><th>Guardian</th><th>Actions</th>
        </tr>
      </thead>
      <tbody data-hms-rows>
        <?php foreach ($students as $s): ?>
          <tr data-row>
            <td class="door-plate">#<?= (int) $s['student_id'] ?></td>
            <td><?= e($s['name']) ?></td>
            <td><?= e($s['gender']) ?></td>
            <td><?= e($s['department']) ?></td>
            <td><?= (int) $s['year'] ?></td>
            <td><?= e($s['mobile']) ?></td>
            <td><?= e($s['guardian_name']) ?> <span style="color:var(--h-text-dim);">(<?= e($s['guardian_mobile']) ?>)</span></td>
            <td class="text-nowrap">
              <a href="admin_student_form.php?id=<?= (int) $s['student_id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
              <form action="admin_student_delete.php" method="post" class="d-inline"
                    data-confirm data-confirm-title="Delete this student?"
                    data-confirm-text="This removes student #<?= (int) $s['student_id'] ?> (<?= e($s['name']) ?>) permanently. This cannot be undone.">
                <?= csrf_field() ?>
                <input type="hidden" name="student_id" value="<?= (int) $s['student_id'] ?>">
                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="hms-pagination" data-hms-pagination data-page-size="8"></div>
<?php endif; ?>
</div>

<?php require 'includes/footer.php'; ?>
