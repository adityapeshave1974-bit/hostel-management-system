<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

$id = isset($_GET['id']) ? (int) $_GET['id'] : null;
$room = ['room_id' => null, 'room_no' => '', 'block' => '', 'floor' => '', 'capacity' => 1, 'occupied_beds' => 0];
$errors = [];

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM rooms WHERE room_id = ?');
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if (!$found) {
        set_flash('error', 'Room not found.');
        redirect('admin_rooms.php');
    }
    $room = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $room['room_no']  = trim($_POST['room_no'] ?? '');
    $room['block']    = trim($_POST['block'] ?? '');
    $room['floor']    = trim($_POST['floor'] ?? '');
    $room['capacity'] = (int) ($_POST['capacity'] ?? 0);

    if ($room['room_no'] === '') $errors[] = 'Room number is required.';
    if ($room['block'] === '') $errors[] = 'Block is required.';
    if ($room['floor'] === '') $errors[] = 'Floor is required.';
    if ($room['capacity'] < 1) $errors[] = 'Capacity must be at least 1.';
    if ($room['capacity'] > 8) $errors[] = 'Capacity cannot exceed 8 beds.';
    if ($id && $room['capacity'] < (int) $room['occupied_beds']) {
        $errors[] = "Capacity can't be less than the {$room['occupied_beds']} bed(s) currently occupied.";
    }

    if (!$errors) {
        // Check room_no uniqueness (excluding this room when editing).
        $check = $id
            ? $pdo->prepare('SELECT room_id FROM rooms WHERE room_no = ? AND room_id != ?')
            : $pdo->prepare('SELECT room_id FROM rooms WHERE room_no = ?');
        $id ? $check->execute([$room['room_no'], $id]) : $check->execute([$room['room_no']]);
        if ($check->fetch()) {
            $errors[] = 'A room with this Room No already exists.';
        }
    }

    if (!$errors) {
        if ($id) {
            $stmt = $pdo->prepare('UPDATE rooms SET room_no=?, block=?, floor=?, capacity=? WHERE room_id=?');
            $stmt->execute([$room['room_no'], $room['block'], $room['floor'], $room['capacity'], $id]);
            set_flash('success', 'Room updated.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO rooms (room_no, block, floor, capacity) VALUES (?, ?, ?, ?)');
            $stmt->execute([$room['room_no'], $room['block'], $room['floor'], $room['capacity']]);
            set_flash('success', 'Room added.');
        }
        redirect('admin_rooms.php');
    }
}

$pageTitle = $id ? 'Edit Room' : 'Add Room';
require 'includes/header.php';
?>

<?php hms_page_head($id ? 'Edit Room ' . e($room['room_no']) : 'Add Room', $id ? e($room['block']) . ', Floor ' . e($room['floor']) : 'Create a new room'); ?>

<?php if ($errors): ?>
  <div class="alert-banner alert-banner-danger">
    <ul class="mb-0 ps-3"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="hms-card hms-card-pad hms-form-card" style="max-width:600px;">
<form method="post">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Room No</label>
      <input type="text" name="room_no" class="form-control" value="<?= e($room['room_no']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Block</label>
      <input type="text" name="block" class="form-control" value="<?= e($room['block']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Floor</label>
      <input type="text" name="floor" class="form-control" value="<?= e($room['floor']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Capacity (beds)</label>
      <input type="number" name="capacity" min="1" max="8" class="form-control" value="<?= (int) $room['capacity'] ?>" required>
      <div class="form-text">Maximum 8 beds per room.</div>
      <?php if ($id): ?>
        <div class="form-text"><?= (int) $room['occupied_beds'] ?> bed(s) currently occupied.</div>
      <?php endif; ?>
    </div>
  </div>
  <div class="mt-4 d-flex gap-2">
    <button type="submit" class="btn btn-primary"><?= icon('check-circle') ?> Save</button>
    <a href="admin_rooms.php" class="btn btn-outline-secondary">Cancel</a>
  </div>
</form>
</div>

<?php require 'includes/footer.php'; ?>
