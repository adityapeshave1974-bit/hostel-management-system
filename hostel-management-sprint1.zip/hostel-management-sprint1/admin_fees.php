<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

$statusFilter = $_GET['status'] ?? '';
$sql = "SELECT f.*, s.name AS student_name FROM fees f JOIN students s ON s.student_id = f.student_id";
$params = [];
if ($statusFilter === 'Pending' || $statusFilter === 'Paid') {
    $sql .= " WHERE f.status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY f.due_date DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$fees = $stmt->fetchAll();

$totals = $pdo->query(
    "SELECT
        COALESCE(SUM(CASE WHEN status='Paid' THEN amount ELSE 0 END),0) AS collected,
        COALESCE(SUM(CASE WHEN status='Pending' THEN amount ELSE 0 END),0) AS pending
     FROM fees"
)->fetch();

$pageTitle = 'Fees';
require 'includes/header.php';
?>

<?php
hms_page_head(
    'Fees',
    'Track dues and record payments',
    '<a href="admin_fee_form.php" class="btn btn-primary btn-sm">' . icon('plus') . ' Add Fee Due</a>'
);
?>

<div class="hms-stat-grid hms-stat-grid-2" style="max-width:640px;">
  <?= hms_stat('Collected', '&#8377;' . number_format((float) $totals['collected']), 'wallet', 'success') ?>
  <?= hms_stat('Pending', '&#8377;' . number_format((float) $totals['pending']), 'wallet', 'danger') ?>
</div>

<?php
$feeTotal = (float) $totals['collected'] + (float) $totals['pending'];
$collectedPct = $feeTotal > 0 ? ((float) $totals['collected'] / $feeTotal) * 100 : 0;
?>
<div class="hms-card hms-card-pad mb-3" style="max-width:640px;">
  <?= hms_progress('Fee collection progress', $collectedPct, round($collectedPct) . '% collected', 'success') ?>
</div>

<div class="hms-tabs">
  <a href="admin_fees.php" class="hms-tab<?= $statusFilter === '' ? ' is-active' : '' ?>">All</a>
  <a href="admin_fees.php?status=Pending" class="hms-tab<?= $statusFilter === 'Pending' ? ' is-active' : '' ?>">Pending</a>
  <a href="admin_fees.php?status=Paid" class="hms-tab<?= $statusFilter === 'Paid' ? ' is-active' : '' ?>">Paid</a>
</div>

<div class="hms-card" data-hms-table>
<?php if (!$fees): ?>
  <?php hms_empty('wallet', 'No fee records found', 'Add a fee due to start tracking payments.'); ?>
<?php else: ?>
  <div class="hms-table-toolbar">
    <div class="hms-table-search"><?= icon('search') ?><input type="text" data-hms-search placeholder="Search by student"></div>
    <div class="hms-table-meta" data-hms-count></div>
  </div>
  <div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
      <thead>
        <tr><th>Student</th><th>Amount</th><th>Due Date</th><th>Paid Date</th><th>Mode</th><th>Status</th><th>Actions</th></tr>
      </thead>
      <tbody data-hms-rows>
        <?php foreach ($fees as $f): ?>
          <tr data-row>
            <td><?= e($f['student_name']) ?> <span style="color:var(--h-text-dim);">#<?= (int) $f['student_id'] ?></span></td>
            <td>&#8377;<?= number_format((float) $f['amount']) ?></td>
            <td><?= e($f['due_date']) ?></td>
            <td><?= e($f['paid_date'] ?? '&mdash;') ?></td>
            <td><?= e($f['mode'] ?? '&mdash;') ?></td>
            <td><?= hms_status_badge($f['status']) ?></td>
            <td>
              <?php if ($f['status'] === 'Pending'): ?>
                <form action="admin_fee_pay.php" method="post" class="d-flex gap-2 align-items-center">
                  <?= csrf_field() ?>
                  <input type="hidden" name="fee_id" value="<?= (int) $f['fee_id'] ?>">
                  <select name="mode" class="form-select form-select-sm" style="width:auto;" required>
                    <option value="">Mode&hellip;</option>
                    <option value="Cash">Cash</option>
                    <option value="UPI">UPI</option>
                    <option value="Card">Card</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                  </select>
                  <button type="submit" class="btn btn-sm btn-outline-primary">Mark Paid</button>
                </form>
              <?php else: ?>
                <span style="color:var(--h-text-dim);">&mdash;</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="hms-pagination" data-hms-pagination data-page-size="8"></div>
<?php endif; ?>
</div>

<?php require 'includes/footer.php'; ?>
