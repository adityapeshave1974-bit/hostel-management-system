<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('warden');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $userId = (int) ($_POST['user_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if (!in_array($action, ['approve', 'reject'], true)) {
        set_flash('error', 'Invalid action.');
        redirect('warden_approvals.php');
    }

    $stmt = $pdo->prepare("SELECT id, full_name, status FROM users WHERE id = ? AND role = 'student' LIMIT 1");
    $stmt->execute([$userId]);
    $account = $stmt->fetch();

    if (!$account) {
        set_flash('error', 'That registration request was not found.');
        redirect('warden_approvals.php');
    }

    $newStatus = $action === 'approve' ? 'approved' : 'rejected';
    $stmt = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
    $stmt->execute([$newStatus, $userId]);

    set_flash('success', e($account['full_name']) . ($action === 'approve'
        ? ' has been approved and can now log in.'
        : ' has been rejected.'));
    redirect('warden_approvals.php');
}

$statusFilter = $_GET['status'] ?? 'pending';
if (!in_array($statusFilter, ['pending', 'approved', 'rejected'], true)) {
    $statusFilter = 'pending';
}

$stmt = $pdo->prepare(
    "SELECT u.id, u.username, u.full_name, u.status, u.created_at, u.student_id,
            s.department, s.year, s.mobile
     FROM users u
     LEFT JOIN students s ON s.student_id = u.student_id
     WHERE u.role = 'student' AND u.status = ?
     ORDER BY u.created_at DESC"
);
$stmt->execute([$statusFilter]);
$requests = $stmt->fetchAll();

$pendingCount = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student' AND status = 'pending'")->fetchColumn();

$pageTitle = 'Registration Approvals';
require 'includes/header.php';
?>

<?php hms_page_head('Registration Approvals', 'Students who registered a login link it to a Student ID an admin already created — review and approve or reject each request.'); ?>

<div class="hms-stat-grid">
  <?= hms_stat('Awaiting Approval', (string) $pendingCount, 'user-check', $pendingCount > 0 ? 'warning' : 'success') ?>
</div>

<div class="hms-tabs" style="margin-top:1.25rem;">
  <a href="warden_approvals.php?status=pending" class="hms-tab<?= $statusFilter === 'pending' ? ' is-active' : '' ?>">Pending</a>
  <a href="warden_approvals.php?status=approved" class="hms-tab<?= $statusFilter === 'approved' ? ' is-active' : '' ?>">Approved</a>
  <a href="warden_approvals.php?status=rejected" class="hms-tab<?= $statusFilter === 'rejected' ? ' is-active' : '' ?>">Rejected</a>
</div>

<div class="hms-card" data-hms-table>
<?php if (!$requests): ?>
  <?php hms_empty('user-check', 'Nothing here', 'No ' . $statusFilter . ' registration requests right now.'); ?>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
      <thead>
        <tr>
          <th>Student</th><th>Username</th><th>Student ID</th><th>Department</th>
          <th>Mobile</th><th>Requested</th><th>Status</th>
          <?php if ($statusFilter === 'pending'): ?><th>Actions</th><?php endif; ?>
        </tr>
      </thead>
      <tbody data-hms-rows>
        <?php foreach ($requests as $r): ?>
          <tr data-row>
            <td><?= e($r['full_name']) ?></td>
            <td><?= e($r['username']) ?></td>
            <td class="door-plate">#<?= (int) $r['student_id'] ?></td>
            <td><?= e($r['department'] ?? '—') ?></td>
            <td><?= e($r['mobile'] ?? '—') ?></td>
            <td><?= e($r['created_at']) ?></td>
            <td><?= hms_status_badge(ucfirst($r['status'])) ?></td>
            <?php if ($statusFilter === 'pending'): ?>
              <td class="text-nowrap">
                <form method="post" class="d-inline">
                  <?= csrf_field() ?>
                  <input type="hidden" name="user_id" value="<?= (int) $r['id'] ?>">
                  <input type="hidden" name="action" value="approve">
                  <button type="submit" class="btn btn-sm btn-outline-success">Approve</button>
                </form>
                <form method="post" class="d-inline"
                      data-confirm data-confirm-title="Reject this request?"
                      data-confirm-text="<?= e($r['full_name']) ?> won't be able to log in until they're approved.">
                  <?= csrf_field() ?>
                  <input type="hidden" name="user_id" value="<?= (int) $r['id'] ?>">
                  <input type="hidden" name="action" value="reject">
                  <button type="submit" class="btn btn-sm btn-outline-danger">Reject</button>
                </form>
              </td>
            <?php endif; ?>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>
</div>

<?php require 'includes/footer.php'; ?>
