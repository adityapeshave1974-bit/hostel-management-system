<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

$errors = [];
$old = ['username' => '', 'student_id' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $username    = trim($_POST['username'] ?? '');
    $password    = $_POST['password'] ?? '';
    $confirm     = $_POST['confirm_password'] ?? '';
    $student_id  = trim($_POST['student_id'] ?? '');

    $old['username']   = $username;
    $old['student_id'] = $student_id;

    if ($username === '' || $password === '' || $student_id === '') {
        $errors[] = 'All fields are required.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Password and confirm password do not match.';
    }

    $expectedCaptcha = (int) ($_SESSION['captcha_a'] ?? 0) + (int) ($_SESSION['captcha_b'] ?? 0);
    $givenCaptcha    = (int) ($_POST['captcha_answer'] ?? -1);
    unset($_SESSION['captcha_a'], $_SESSION['captcha_b']);
    if ($givenCaptcha !== $expectedCaptcha) {
        $errors[] = 'That verification answer was incorrect.';
    }

    if (!$errors) {
        // The student record must already exist — it's created by the
        // administrator via Student Management (FR2). Registration only
        // links a login account to that existing record.
        $stmt = $pdo->prepare('SELECT student_id, name FROM students WHERE student_id = ? LIMIT 1');
        $stmt->execute([$student_id]);
        $student = $stmt->fetch();

        if (!$student) {
            $errors[] = 'No student record found with that Student ID. Ask your hostel administrator to add your record first.';
        } else {
            $stmt = $pdo->prepare('SELECT id FROM users WHERE student_id = ? LIMIT 1');
            $stmt->execute([$student_id]);
            if ($stmt->fetch()) {
                $errors[] = 'An account already exists for this Student ID.';
            }
        }

        if (!$errors) {
            $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                $errors[] = 'That username is already taken.';
            }
        }

        if (!$errors) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                'INSERT INTO users (username, password, role, full_name, student_id, status) VALUES (?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([$username, $hash, 'student', $student['name'], $student_id, 'pending']);
            set_flash('success', 'Account request submitted. A warden needs to approve it before you can log in — check back soon.');
            redirect('login.php');
        }
    }
}

$_SESSION['captcha_a'] = random_int(1, 9);
$_SESSION['captcha_b'] = random_int(1, 9);

$pageTitle = 'Register';
require 'includes/header.php';
?>

<div class="auth-split">
  <div class="auth-visual" style="background-image:url('assets/images/hostel.jpg');">
    <div class="auth-visual-overlay">
      <div class="auth-visual-brand">Bam Bir Hostel</div>
      <p class="auth-visual-tag">Home away from home &mdash; managed simply.</p>
    </div>
  </div>
  <div class="auth-form-pane">
    <div class="auth-form-card reveal">
      <h1 class="auth-title">Create your account</h1>
      <p class="auth-subtitle">Use the Student ID your hostel administrator gave you</p>

      <?php if ($errors): ?>
        <div class="alert-banner alert-banner-danger">
          <ul class="mb-0 ps-3">
            <?php foreach ($errors as $err): ?>
              <li><?= e($err) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="post" novalidate>
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label">Student ID</label>
          <input type="text" name="student_id" class="form-control" value="<?= e($old['student_id']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Choose a Username</label>
          <input type="text" name="username" class="form-control" value="<?= e($old['username']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" minlength="6" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Confirm Password</label>
          <input type="password" name="confirm_password" class="form-control" minlength="6" required>
        </div>

        <div class="captcha-box">
          <label class="form-label">&#128737;&#65039; Quick check &mdash; what is <?= (int) $_SESSION['captcha_a'] ?> + <?= (int) $_SESSION['captcha_b'] ?>?</label>
          <input type="text" inputmode="numeric" name="captcha_answer" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Register</button>
      </form>
      <p class="text-center mt-3 mb-0" style="color:var(--text-muted);">
        Already have an account? <a href="login.php">Login</a>
      </p>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
