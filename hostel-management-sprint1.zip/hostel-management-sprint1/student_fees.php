<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('student');

$studentId = $_SESSION['student_id'];

$stmt = $pdo->prepare('SELECT * FROM fees WHERE student_id = ? ORDER BY due_date DESC');
$stmt->execute([$studentId]);
$fees = $stmt->fetchAll();

$pageTitle = 'My Fees';
require 'includes/header.php';
?>

<?php hms_page_head('My Fees', count($fees) . ' record' . (count($fees) === 1 ? '' : 's') . ' on file'); ?>

<div class="hms-card" data-hms-table>
<?php if (!$fees): ?>
  <?php hms_empty('wallet', 'No fee records yet', 'Any dues added by the hostel admin will show up here.'); ?>
<?php else: ?>
  <div class="table-responsive">
    <table class="table mb-0 align-middle">
      <thead><tr><th>Amount</th><th>Due Date</th><th>Paid Date</th><th>Mode</th><th>Status</th></tr></thead>
      <tbody data-hms-rows>
        <?php foreach ($fees as $f): ?>
          <tr data-row>
            <td>&#8377;<?= number_format((float) $f['amount']) ?></td>
            <td><?= e($f['due_date']) ?></td>
            <td><?= e($f['paid_date'] ?? '&mdash;') ?></td>
            <td><?= e($f['mode'] ?? '&mdash;') ?></td>
            <td><?= hms_status_badge($f['status']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="hms-pagination" data-hms-pagination data-page-size="10"></div>
<?php endif; ?>
</div>

<?php require 'includes/footer.php'; ?>
