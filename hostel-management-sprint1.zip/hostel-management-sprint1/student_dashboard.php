<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('student');

$studentId = $_SESSION['student_id'];

$stmt = $pdo->prepare('SELECT * FROM students WHERE student_id = ?');
$stmt->execute([$studentId]);
$student = $stmt->fetch();

$stmt = $pdo->prepare(
    "SELECT r.room_no, r.block, r.floor, ra.allocated_date
     FROM room_allocations ra JOIN rooms r ON r.room_id = ra.room_id
     WHERE ra.student_id = ? AND ra.vacated_date IS NULL"
);
$stmt->execute([$studentId]);
$room = $stmt->fetch();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM fees WHERE student_id = ? AND status='Pending'");
$stmt->execute([$studentId]);
$pendingFees = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM complaints WHERE student_id = ? AND status != 'Resolved'");
$stmt->execute([$studentId]);
$openComplaints = (int) $stmt->fetchColumn();

$pageTitle = 'My Dashboard';
require 'includes/header.php';
?>

<div class="hms-page-head">
  <div>
    <h1 class="hms-page-title">Welcome back, <?= e(explode(' ', $_SESSION['full_name'])[0]) ?></h1>
    <p class="hms-page-subtitle">Your profile, room, fees, and complaints — all in one place.</p>
  </div>
</div>

<div class="hms-stat-grid hms-stat-grid-3">
  <?= hms_stat('Pending Fees', (string) $pendingFees, 'wallet', $pendingFees > 0 ? 'warning' : 'success') ?>
  <?= hms_stat('Open Complaints', (string) $openComplaints, 'complaints', $openComplaints > 0 ? 'danger' : 'success') ?>
  <?= hms_stat('My Room', $room ? e($room['room_no']) : '&mdash;', 'door', $room ? 'violet' : '') ?>
</div>

<div class="hms-grid-2">
  <div class="hms-card hms-card-pad">
    <div class="hms-section-title"><h5><?= icon('students') ?> My Profile</h5></div>
    <?php if ($student): ?>
      <table class="table table-borderless mb-0">
        <tr><th>Student ID</th><td>#<?= (int) $student['student_id'] ?></td></tr>
        <tr><th>Name</th><td><?= e($student['name']) ?></td></tr>
        <tr><th>Gender</th><td><?= e($student['gender']) ?></td></tr>
        <tr><th>Department</th><td><?= e($student['department']) ?></td></tr>
        <tr><th>Year</th><td><?= (int) $student['year'] ?></td></tr>
        <tr><th>Mobile</th><td><?= e($student['mobile']) ?></td></tr>
        <tr><th>Guardian</th><td><?= e($student['guardian_name']) ?> (<?= e($student['guardian_mobile']) ?>)</td></tr>
      </table>
    <?php else: ?>
      <?php hms_empty('students', 'Profile not found', 'Contact your administrator.'); ?>
    <?php endif; ?>
  </div>

  <div class="hms-card hms-card-pad">
    <div class="hms-section-title"><h5><?= icon('door') ?> My Room</h5></div>
    <?php if ($room): ?>
      <table class="table table-borderless mb-0">
        <tr><th>Room No</th><td><span class="door-plate"><?= e($room['room_no']) ?></span></td></tr>
        <tr><th>Block</th><td><?= e($room['block']) ?></td></tr>
        <tr><th>Floor</th><td><?= e($room['floor']) ?></td></tr>
        <tr><th>Allocated Since</th><td><?= e($room['allocated_date']) ?></td></tr>
      </table>
    <?php else: ?>
      <?php hms_empty('door', 'No room allocated yet', 'Contact the hostel administrator.'); ?>
    <?php endif; ?>
  </div>
</div>

<div class="hms-section-title" style="margin-top:1.5rem;"><h5><?= icon('bell') ?> Quick Actions</h5></div>
<div class="hms-tile-grid">
  <?= hms_tile('wallet', 'Fees', $pendingFees . ' payment' . ($pendingFees === 1 ? '' : 's') . ' pending.', 'student_fees.php', 'View My Fees') ?>
  <?= hms_tile('complaints', 'Complaints', $openComplaints . ' open complaint' . ($openComplaints === 1 ? '' : 's') . '.', 'student_complaints.php', 'View My Complaints') ?>
  <?= hms_tile('notices', 'Notices', 'Check the latest hostel announcements.', 'notices.php', 'View Notices') ?>
</div>

<?php require 'includes/footer.php'; ?>
