<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

$id = isset($_GET['id']) ? (int) $_GET['id'] : null;
$student = [
    'student_id' => null, 'name' => '', 'gender' => 'Male', 'department' => '',
    'year' => 1, 'mobile' => '', 'guardian_name' => '', 'guardian_mobile' => '',
];
$errors = [];

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM students WHERE student_id = ?');
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if (!$found) {
        set_flash('error', 'Student not found.');
        redirect('admin_students.php');
    }
    $student = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $student['name']            = trim($_POST['name'] ?? '');
    $student['gender']          = trim($_POST['gender'] ?? '');
    $student['department']      = trim($_POST['department'] ?? '');
    $student['year']            = (int) ($_POST['year'] ?? 0);
    $mobileCode                 = trim($_POST['mobile_code'] ?? '+91');
    $mobileDigits                = trim($_POST['mobile'] ?? '');
    $student['mobile']          = $mobileDigits !== '' ? $mobileCode . ' ' . $mobileDigits : '';
    $student['guardian_name']   = trim($_POST['guardian_name'] ?? '');
    $guardianCode                = trim($_POST['guardian_mobile_code'] ?? '+91');
    $guardianDigits               = trim($_POST['guardian_mobile'] ?? '');
    $student['guardian_mobile'] = $guardianDigits !== '' ? $guardianCode . ' ' . $guardianDigits : '';

    if ($student['name'] === '') $errors[] = 'Name is required.';
    if ($student['department'] === '') $errors[] = 'Department is required.';
    if ($student['year'] < 1 || $student['year'] > 6) $errors[] = 'Year must be between 1 and 6.';
    if (!preg_match('/^[0-9]{7,15}$/', $mobileDigits)) $errors[] = 'Mobile number must be 7-15 digits.';
    if ($student['guardian_name'] === '') $errors[] = 'Guardian name is required.';
    if (!preg_match('/^[0-9]{7,15}$/', $guardianDigits)) $errors[] = 'Guardian mobile must be 7-15 digits.';

    if (!$errors) {
        if ($id) {
            $stmt = $pdo->prepare(
                'UPDATE students SET name=?, gender=?, department=?, year=?, mobile=?, guardian_name=?, guardian_mobile=?
                 WHERE student_id=?'
            );
            $stmt->execute([
                $student['name'], $student['gender'], $student['department'], $student['year'],
                $student['mobile'], $student['guardian_name'], $student['guardian_mobile'], $id,
            ]);
            set_flash('success', 'Student record updated.');
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO students (name, gender, department, year, mobile, guardian_name, guardian_mobile)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $student['name'], $student['gender'], $student['department'], $student['year'],
                $student['mobile'], $student['guardian_name'], $student['guardian_mobile'],
            ]);
            set_flash('success', 'Student added. They can now register a login using their Student ID.');
        }
        redirect('admin_students.php');
    }
}

$pageTitle = $id ? 'Edit Student' : 'Add Student';
require 'includes/header.php';
?>

<?php hms_page_head($id ? 'Edit Student #' . (int) $id : 'Add Student', $id ? e($student['name']) : 'Create a new student record'); ?>

<?php if ($errors): ?>
  <div class="alert-banner alert-banner-danger">
    <ul class="mb-0 ps-3"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="hms-card hms-card-pad hms-form-card">
<form method="post">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Full Name</label>
      <input type="text" name="name" class="form-control" value="<?= e($student['name']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Gender</label>
      <select name="gender" class="form-select">
        <?php foreach (['Male', 'Female', 'Other'] as $g): ?>
          <option value="<?= $g ?>" <?= $student['gender'] === $g ? 'selected' : '' ?>><?= $g ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-6">
      <label class="form-label">Department</label>
      <input type="text" name="department" class="form-control" value="<?= e($student['department']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Year</label>
      <input type="number" name="year" min="1" max="6" class="form-control" value="<?= (int) $student['year'] ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Mobile Number</label>
      <?php phone_input('mobile', $student['mobile']); ?>
    </div>
    <div class="col-md-6"></div>
    <div class="col-md-6">
      <label class="form-label">Guardian Name</label>
      <input type="text" name="guardian_name" class="form-control" value="<?= e($student['guardian_name']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Guardian Mobile</label>
      <?php phone_input('guardian_mobile', $student['guardian_mobile']); ?>
    </div>
  </div>
  <div class="mt-4 d-flex gap-2">
    <button type="submit" class="btn btn-primary"><?= icon('check-circle') ?> Save</button>
    <a href="admin_students.php" class="btn btn-outline-secondary">Cancel</a>
  </div>
</form>
</div>

<?php require 'includes/footer.php'; ?>
