# Hostel Management System — Sprint 1 + Sprint 2

A working PHP + MySQL build covering the full SRS scope:

- **User Authentication** — login (with a simple CAPTCHA), student self-registration, logout, role-based access (Admin / Warden / Student), sessions
- **Student Management** — add, edit, delete, search
- **Room Management** — add, edit, delete rooms; allocate students to beds; vacate
- **Fee Management** — record dues, mark as paid, students view their own payment history
- **Complaint Management** — students file complaints; admin/warden triage and respond
- **Notices** — admin posts hostel-wide announcements; everyone sees them
- **Reports** — Student, Room Occupancy, Fee Collection, and Complaint reports
- **Notification bell** — a top bar with a live count of things needing attention (role-specific)

Visitor Management isn't in this build (it wasn't asked for alongside the rest of Sprint 2) — say the word if you want it added.

## 1. Requirements

- XAMPP (or any Apache + PHP 8+ + MySQL stack)
- A browser

## 2. Setup

1. Copy this whole `hostel-management-sprint1` folder into your server's web root,
   e.g. `C:\xampp\htdocs\hostel-management-sprint1` (Windows) or `/opt/lampp/htdocs/hostel-management-sprint1` (Linux).
2. Start **Apache** and **MySQL** from the XAMPP control panel.
3. Open **phpMyAdmin** → **Import** → choose `sql/schema.sql` → Go.
   This creates the `hostel_management` database and all tables. If you already
   had Sprint 1 imported, re-running this file is safe — it only adds the new
   `fees`, `complaints`, and `notices` tables and won't touch your existing data.
4. If your MySQL root user has a password, or you're not using `localhost`,
   edit `config/database.php` and update `DB_HOST` / `DB_USER` / `DB_PASS`.
5. In your browser, visit:
   `http://localhost/hostel-management-sprint1/setup_seed.php`
   This creates the first two logins:
   - **Admin** — username `admin`, password `Admin@123`
   - **Warden** — username `warden1`, password `Warden@123`
   - **Student** — username `student1`, password `Student@123` (a demo student "Aditi Sharma" pre-allocated to Room A-101, so the student view isn't empty on first login)
6. **Delete `setup_seed.php`** from the folder now that it's done its job — it should never sit on a live server.
7. Go to `http://localhost/hostel-management-sprint1/login.php` and log in as admin.

## 3. Trying it out

1. Log in as **admin** → **Manage Students** → add a couple of students.
2. **Manage Rooms** → add a room (e.g. Room 101, Block A, Floor 1, Capacity 2).
3. Click **Manage Occupants** on that room → allocate one of the students you added.
4. Go to **Fees** → add a due for a student, then mark it paid.
5. Go to **Notices** → post an announcement.
6. Log out, then have that student **register** (`register.php`) using the Student ID
   you gave them, and log in as them — they'll see their fees, can file a complaint,
   and will see the notice you posted.
7. Back in as **admin** (or **warden1**), go to **Complaints** to respond to it —
   the student will see your response and status change on their own login, and
   the bell icon in the top bar will reflect it.


## 4. Project Structure

```
hostel-management-sprint1/
├── config/database.php        PDO connection settings
├── includes/                  auth.php, functions.php, notifications.php, site_content.php, header.php, footer.php
├── assets/css/style.css       glass/neon styling on top of Bootstrap 5
├── assets/images/hostel.jpg   the hostel photo shown on login/register
├── sql/schema.sql             database schema (import this first — safe to re-run)
├── setup_seed.php             one-time script — creates admin/warden/student logins, then delete it
├── index.php, login.php, register.php, logout.php, dashboard.php
├── admin_dashboard.php, admin_students.php, admin_student_form.php, admin_student_delete.php
├── admin_rooms.php, admin_room_form.php, admin_room_delete.php, admin_room_manage.php
├── admin_fees.php, admin_fee_form.php, admin_fee_pay.php
├── admin_reports.php
├── staff_complaints.php        shared by admin + warden
├── notices.php                 shared by every role (admin can post/remove)
├── warden_dashboard.php
├── student_dashboard.php, student_fees.php
└── student_complaints.php, student_complaint_new.php
```

All pages live in one folder on purpose (no `admin/`, `warden/` subfolders) so every
`include`/link path stays simple and nothing breaks if you rename the project folder.
`staff_` prefixes a page shared by both staff roles; everything else without a role
prefix (like `notices.php`) is open to any logged-in role, with admin-only controls
shown conditionally inside the page.

## 5. Using your own hostel photo on the login screen

The login and register pages currently show `assets/images/hostel.jpg`. To swap
in a different photo later:

1. Drop your photo into `assets/images/`, e.g. `hostel-v2.jpg`.
2. In `login.php` and `register.php`, find this line:
   `style="background-image:url('assets/images/hostel.jpg');"`
   and change the filename.

A tall-ish, well-lit photo of the building's front (portrait or square works
better than a wide panorama, since the image only fills roughly the left
half of the screen) will look best.

## 6. Login page content (facts, reviews, CAPTCHA, contact)

The login page includes:

- **Rotating hostel facts** and **sample reviews** — edit `includes/site_content.php`
  to change these. The reviews are placeholder text, not real guest feedback —
  presenting made-up reviews as genuine to real visitors isn't something to launch
  with, so swap in real testimonials before this goes live.
- **A simple math CAPTCHA** on both login and register — no external service or
  API key required. Two random numbers are generated server-side each time the
  form loads and checked on submit. It stops basic scripted submissions; it isn't
  a replacement for reCAPTCHA if you expect determined bots.
- **Contact line** — also set in `includes/site_content.php` (`CONTACT_NAME` /
  `CONTACT_PHONE`).

## 7. Notes for the developer picking this up

- Passwords are hashed with `password_hash()` / verified with `password_verify()` — never stored in plain text.
- All forms include a CSRF token (`csrf_field()` / `verify_csrf()` in `includes/auth.php`).
- All DB queries use PDO prepared statements — no raw string concatenation into SQL.
- A student can hold only **one active room allocation** at a time; this is enforced in
  `admin_room_manage.php`, not by a DB constraint (MySQL can't express a "unique while active" rule directly).
- Deleting a student who currently occupies a room, or deleting a room that still has
  occupants, is blocked with a clear message — vacate first.
- The notification bell (`includes/notifications.php`) computes its list fresh on
  every page load — there's no "read/unread" tracking table yet, so an item stays
  in the list until the underlying record changes (e.g. a complaint moves out of
  "Pending"). Fine for a demo; add a `notification_reads` table if this needs real
  per-user read state later.
- Fee, Complaint, and Notice management are now live (this used to be the Sprint 2
  placeholder note — it isn't anymore).
