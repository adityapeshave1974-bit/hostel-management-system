<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('student');

$errors = [];
$old = ['subject' => '', 'description' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $old['subject']     = trim($_POST['subject'] ?? '');
    $old['description'] = trim($_POST['description'] ?? '');

    if ($old['subject'] === '') $errors[] = 'Subject is required.';
    if ($old['description'] === '') $errors[] = 'Please describe the issue.';

    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO complaints (student_id, subject, description) VALUES (?, ?, ?)');
        $stmt->execute([$_SESSION['student_id'], $old['subject'], $old['description']]);
        set_flash('success', 'Complaint filed. The hostel staff will review it shortly.');
        redirect('student_complaints.php');
    }
}

$pageTitle = 'File a Complaint';
require 'includes/header.php';
?>

<?php
hms_page_head(
    'File a Complaint',
    'Let the hostel staff know what needs attention',
    '<a href="student_complaints.php" class="btn btn-outline-secondary btn-sm">' . icon('arrow-left') . ' Back</a>'
);
?>

<?php if ($errors): ?>
  <div class="alert-banner alert-banner-danger">
    <ul class="mb-0 ps-3"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="hms-card hms-card-pad hms-form-card">
<form method="post">
  <?= csrf_field() ?>
  <div class="mb-3">
    <label class="form-label">Subject</label>
    <input type="text" name="subject" class="form-control" value="<?= e($old['subject']) ?>" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Description</label>
    <textarea name="description" class="form-control" rows="5" required><?= e($old['description']) ?></textarea>
  </div>
  <div class="d-flex gap-2">
    <button type="submit" class="btn btn-primary"><?= icon('check-circle') ?> Submit</button>
    <a href="student_complaints.php" class="btn btn-outline-secondary">Cancel</a>
  </div>
</form>
</div>

<?php require 'includes/footer.php'; ?>
