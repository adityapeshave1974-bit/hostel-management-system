<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

$students = $pdo->query('SELECT student_id, name FROM students ORDER BY name')->fetchAll();
$errors = [];
$old = ['student_id' => '', 'amount' => '', 'due_date' => date('Y-m-d')];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $old['student_id'] = $_POST['student_id'] ?? '';
    $old['amount']      = $_POST['amount'] ?? '';
    $old['due_date']    = $_POST['due_date'] ?? '';

    $studentId = (int) $old['student_id'];
    $amount    = (float) $old['amount'];

    if ($studentId <= 0) $errors[] = 'Please choose a student.';
    if ($amount <= 0) $errors[] = 'Amount must be greater than 0.';
    if ($old['due_date'] === '') $errors[] = 'Due date is required.';

    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO fees (student_id, amount, due_date) VALUES (?, ?, ?)');
        $stmt->execute([$studentId, $amount, $old['due_date']]);
        set_flash('success', 'Fee due added.');
        redirect('admin_fees.php');
    }
}

$pageTitle = 'Add Fee Due';
require 'includes/header.php';
?>

<?php hms_page_head('Add Fee Due', 'Record a new due for a student'); ?>

<?php if ($errors): ?>
  <div class="alert-banner alert-banner-danger">
    <ul class="mb-0 ps-3"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="hms-card hms-card-pad hms-form-card" style="max-width:560px;">
<form method="post">
  <?= csrf_field() ?>
  <div class="mb-3">
    <label class="form-label">Student</label>
    <select name="student_id" class="form-select" required>
      <option value="">Select a student&hellip;</option>
      <?php foreach ($students as $s): ?>
        <option value="<?= (int) $s['student_id'] ?>" <?= (string) $old['student_id'] === (string) $s['student_id'] ? 'selected' : '' ?>>
          <?= e($s['name']) ?> &mdash; #<?= (int) $s['student_id'] ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="mb-3">
    <label class="form-label">Amount (&#8377;)</label>
    <input type="number" name="amount" min="1" step="1" class="form-control" value="<?= e((string) $old['amount']) ?>" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Due Date</label>
    <input type="date" name="due_date" class="form-control" value="<?= e($old['due_date']) ?>" required>
  </div>
  <div class="d-flex gap-2">
    <button type="submit" class="btn btn-primary"><?= icon('check-circle') ?> Save</button>
    <a href="admin_fees.php" class="btn btn-outline-secondary">Cancel</a>
  </div>
</form>
</div>

<?php require 'includes/footer.php'; ?>
