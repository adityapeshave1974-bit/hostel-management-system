<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role(['admin', 'warden']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $complaintId = (int) ($_POST['complaint_id'] ?? 0);
    $status      = $_POST['status'] ?? '';
    $response    = trim($_POST['response'] ?? '');

    if (!in_array($status, ['Pending', 'In Progress', 'Resolved'], true)) {
        set_flash('error', 'Invalid status.');
        redirect('staff_complaints.php');
    }

    $resolvedAt = $status === 'Resolved' ? date('Y-m-d H:i:s') : null;
    $stmt = $pdo->prepare('UPDATE complaints SET status = ?, response = ?, resolved_at = ? WHERE complaint_id = ?');
    $stmt->execute([$status, $response !== '' ? $response : null, $resolvedAt, $complaintId]);

    set_flash('success', 'Complaint updated.');
    redirect('staff_complaints.php');
}

$statusFilter = $_GET['status'] ?? '';
$sql = "SELECT c.*, s.name AS student_name FROM complaints c JOIN students s ON s.student_id = c.student_id";
$params = [];
if (in_array($statusFilter, ['Pending', 'In Progress', 'Resolved'], true)) {
    $sql .= ' WHERE c.status = ?';
    $params[] = $statusFilter;
}
$sql .= ' ORDER BY c.created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$complaints = $stmt->fetchAll();

$pageTitle = 'Complaints';
require 'includes/header.php';
?>

<?php hms_page_head('Complaints', count($complaints) . ' complaint' . (count($complaints) === 1 ? '' : 's') . ($statusFilter !== '' ? ' &middot; filtered by ' . e($statusFilter) : '')); ?>

<div class="hms-tabs">
  <a href="staff_complaints.php" class="hms-tab<?= $statusFilter === '' ? ' is-active' : '' ?>">All</a>
  <a href="staff_complaints.php?status=Pending" class="hms-tab<?= $statusFilter === 'Pending' ? ' is-active' : '' ?>">Pending</a>
  <a href="staff_complaints.php?status=In+Progress" class="hms-tab<?= $statusFilter === 'In Progress' ? ' is-active' : '' ?>">In Progress</a>
  <a href="staff_complaints.php?status=Resolved" class="hms-tab<?= $statusFilter === 'Resolved' ? ' is-active' : '' ?>">Resolved</a>
</div>

<?php if (!$complaints): ?>
  <div class="hms-card hms-card-pad">
    <?php hms_empty('complaints', 'No complaints found', 'Nothing matches this filter right now.'); ?>
  </div>
<?php endif; ?>

<?php foreach ($complaints as $c): ?>
  <div class="hms-card hms-card-pad mb-3">
    <div class="d-flex justify-content-between flex-wrap gap-2 mb-2">
      <div>
        <strong><?= e($c['subject']) ?></strong>
        <span style="color:var(--h-text-dim);">&mdash; <?= e($c['student_name']) ?> #<?= (int) $c['student_id'] ?></span>
      </div>
      <?= hms_status_badge($c['status']) ?>
    </div>
    <p class="mb-2"><?= nl2br(e($c['description'])) ?></p>
    <div style="color:var(--h-text-dim);font-size:0.78rem;" class="mb-3">Filed <?= e($c['created_at']) ?></div>

    <form method="post" class="row g-2 align-items-start">
      <?= csrf_field() ?>
      <input type="hidden" name="complaint_id" value="<?= (int) $c['complaint_id'] ?>">
      <div class="col-md-3">
        <select name="status" class="form-select form-select-sm">
          <?php foreach (['Pending', 'In Progress', 'Resolved'] as $s): ?>
            <option value="<?= $s ?>" <?= $c['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-7">
        <input type="text" name="response" class="form-control form-control-sm" placeholder="Response / notes for the student (optional)" value="<?= e($c['response'] ?? '') ?>">
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-sm btn-primary w-100">Update</button>
      </div>
    </form>
  </div>
<?php endforeach; ?>

<?php require 'includes/footer.php'; ?>
