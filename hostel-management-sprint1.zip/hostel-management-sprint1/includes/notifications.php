<?php
/**
 * Builds a small, role-specific notification list. This is computed fresh
 * on every page load (no "read/unread" tracking table yet) — good enough
 * for a demo, but worth revisiting if this goes to production with heavy
 * traffic, since it's a handful of extra queries per request.
 */
function get_notifications(PDO $pdo, array $user): array
{
    $items = [];

    if (in_array($user['role'], ['admin', 'warden'], true)) {
        $stmt = $pdo->prepare(
            "SELECT c.subject, c.created_at, s.name
             FROM complaints c JOIN students s ON s.student_id = c.student_id
             WHERE c.status = 'Pending'
             ORDER BY c.created_at DESC LIMIT 5"
        );
        $stmt->execute();
        foreach ($stmt->fetchAll() as $row) {
            $items[] = [
                'text' => e($row['name']) . ' &mdash; ' . e($row['subject']),
                'meta' => 'Pending complaint',
                'time' => $row['created_at'],
                'link' => 'staff_complaints.php',
            ];
        }
    }

    if ($user['role'] === 'warden') {
        $stmt = $pdo->prepare(
            "SELECT full_name, created_at FROM users
             WHERE role = 'student' AND status = 'pending'
             ORDER BY created_at DESC LIMIT 5"
        );
        $stmt->execute();
        foreach ($stmt->fetchAll() as $row) {
            $items[] = [
                'text' => e($row['full_name']) . ' requested a student account',
                'meta' => 'Registration approval',
                'time' => $row['created_at'],
                'link' => 'warden_approvals.php',
            ];
        }
    }

    if ($user['role'] === 'student' && $user['student_id']) {
        $sid = $user['student_id'];

        $stmt = $pdo->prepare(
            "SELECT subject, status, created_at FROM complaints
             WHERE student_id = ? AND status != 'Pending'
             ORDER BY created_at DESC LIMIT 3"
        );
        $stmt->execute([$sid]);
        foreach ($stmt->fetchAll() as $row) {
            $items[] = [
                'text' => 'Complaint &ldquo;' . e($row['subject']) . '&rdquo; is now ' . e($row['status']),
                'meta' => 'Complaint update',
                'time' => $row['created_at'],
                'link' => 'student_complaints.php',
            ];
        }

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM fees WHERE student_id = ? AND status = 'Pending'");
        $stmt->execute([$sid]);
        $pendingFees = (int) $stmt->fetchColumn();
        if ($pendingFees > 0) {
            $items[] = [
                'text' => 'You have ' . $pendingFees . ' pending fee payment' . ($pendingFees > 1 ? 's' : ''),
                'meta' => 'Fees',
                'time' => null,
                'link' => 'student_fees.php',
            ];
        }
    }

    $stmt = $pdo->prepare('SELECT title, created_at FROM notices ORDER BY created_at DESC LIMIT 3');
    $stmt->execute();
    foreach ($stmt->fetchAll() as $row) {
        $items[] = [
            'text' => e($row['title']),
            'meta' => 'Notice',
            'time' => $row['created_at'],
            'link' => 'notices.php',
        ];
    }

    return $items;
}
