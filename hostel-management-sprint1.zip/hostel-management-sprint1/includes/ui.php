<?php
/**
 * Small render helpers for the redesigned authenticated UI. These only
 * produce markup/CSS classes for the new .hms-app theme — they don't touch
 * any data, queries, or business logic.
 */

function hms_page_head(string $title, ?string $subtitle = null, string $actionsHtml = ''): void
{
    echo '<div class="hms-page-head">';
    echo '<div><h1 class="hms-page-title">' . e($title) . '</h1>';
    if ($subtitle !== null && $subtitle !== '') {
        echo '<p class="hms-page-subtitle">' . e($subtitle) . '</p>';
    }
    echo '</div>';
    if ($actionsHtml !== '') {
        echo '<div class="hms-page-actions">' . $actionsHtml . '</div>';
    }
    echo '</div>';
}

/** tone: '', 'success', 'warning', 'danger', 'violet' */
function hms_stat(string $label, string $value, string $iconKey, string $tone = ''): string
{
    $toneClass = $tone !== '' ? ' hms-stat-card--' . $tone : '';
    return '<div class="hms-stat-card' . $toneClass . '">'
        . '<div class="hms-stat-icon">' . icon($iconKey) . '</div>'
        . '<div><div class="hms-stat-label">' . e($label) . '</div>'
        . '<div class="hms-stat-value">' . $value . '</div></div>'
        . '</div>';
}

/** Maps a status string to the same bg-* badge classes already used across the app.
 *  Pending / Full get a slow, subtle pulse — the only statuses worth a second glance. */
function hms_status_badge(string $status): string
{
    $map = [
        'Paid'        => 'bg-success',
        'Resolved'    => 'bg-success',
        'Vacant'      => 'bg-success',
        'Approved'    => 'bg-success',
        'Pending'     => 'bg-danger',
        'Full'        => 'bg-danger',
        'Rejected'    => 'bg-danger',
        'In Progress' => 'bg-warning text-dark',
        'Partially Occupied' => 'bg-warning text-dark',
    ];
    $cls = $map[$status] ?? 'bg-secondary';
    $pulse = in_array($status, ['Pending', 'Full'], true) ? ' hms-badge-pulse' : '';
    return '<span class="badge ' . $cls . $pulse . '">' . e($status) . '</span>';
}

/**
 * A labelled progress bar that animates its fill in from 0 on first paint
 * (the width is set via data-target and picked up by the shared JS in
 * footer.php, so it always animates rather than rendering pre-filled).
 * tone: '', 'success', 'warning', 'danger'
 */
function hms_progress(string $label, float $pct, string $rightText = '', string $tone = ''): string
{
    $pct = max(0, min(100, $pct));
    $toneClass = $tone !== '' ? ' hms-tone-' . $tone : '';
    return '<div class="hms-progress-labelled">'
        . '<div class="hms-progress-labels"><span>' . e($label) . '</span><span>' . e($rightText) . '</span></div>'
        . '<div class="hms-progress"><div class="hms-progress-fill' . $toneClass . '" data-target="' . $pct . '" style="width:0%;"></div></div>'
        . '</div>';
}

/**
 * A small animated SVG donut ring. Renders at 0% and fills in to $pct via
 * the shared JS in footer.php (stroke-dashoffset transition), same
 * animate-on-load treatment as hms_progress().
 * tone: 'cyan' (default), 'success', 'warning', 'danger', 'violet'
 */
function hms_donut(float $pct, string $centerLabel, string $caption, string $tone = 'cyan'): string
{
    $pct = max(0, min(100, $pct));
    $r = 42;
    $circumference = round(2 * M_PI * $r, 2);
    $colorVar = [
        'cyan' => 'var(--h-cyan)', 'success' => 'var(--h-success)',
        'warning' => 'var(--h-warning)', 'danger' => 'var(--h-danger)', 'violet' => 'var(--h-violet)',
    ][$tone] ?? 'var(--h-cyan)';
    return '<div class="hms-donut">'
        . '<svg viewBox="0 0 100 100" width="132" height="132">'
        . '<circle cx="50" cy="50" r="' . $r . '" fill="none" stroke="var(--h-surface-2)" stroke-width="10"/>'
        . '<circle class="hms-donut-fill" cx="50" cy="50" r="' . $r . '" fill="none" stroke="' . $colorVar . '" stroke-width="10"'
        . ' stroke-linecap="round" transform="rotate(-90 50 50)"'
        . ' stroke-dasharray="' . $circumference . '" stroke-dashoffset="' . $circumference . '"'
        . ' data-target-offset="' . round($circumference * (1 - $pct / 100), 2) . '"/>'
        . '</svg>'
        . '<div class="hms-donut-center"><div class="hms-donut-value">' . e($centerLabel) . '</div>'
        . '<div class="hms-donut-caption">' . e($caption) . '</div></div>'
        . '</div>';
}

/**
 * Opens a `.hms-card` containing a search toolbar + table wrapper wired up
 * to the generic client-side search/pagination script in footer.php. Call
 * hms_table_close() (or just echo the closing tags) once the <table> is done.
 * $pageSize = 0 disables pagination (just search).
 */
function hms_table_open(string $searchPlaceholder = 'Search...', int $pageSize = 8): void
{
    echo '<div class="hms-card" data-hms-table>';
    echo '<div class="hms-table-toolbar">';
    echo '<div class="hms-table-search">' . icon('search')
        . '<input type="text" data-hms-search placeholder="' . e($searchPlaceholder) . '"></div>';
    echo '<div class="hms-table-meta" data-hms-count></div>';
    echo '</div>';
    echo '<div class="table-responsive"><table class="table mb-0 align-middle">';
    // caller renders <thead> then <tbody data-hms-rows"> ... </tbody></table>
    if ($pageSize > 0) {
        // stash the page size on a data attribute rendered right after the table close
    }
}

function hms_table_close(int $pageSize = 8): void
{
    echo '</table></div>';
    if ($pageSize > 0) {
        echo '<div class="hms-pagination" data-hms-pagination data-page-size="' . (int) $pageSize . '"></div>';
    }
    echo '</div>';
}

/** One row in an activity feed. */
function hms_feed_item(string $iconKey, string $text, string $meta = ''): string
{
    return '<div class="hms-feed-item">'
        . '<div class="hms-feed-dot">' . icon($iconKey) . '</div>'
        . '<div><div class="hms-feed-text">' . $text . '</div>'
        . ($meta !== '' ? '<div class="hms-feed-meta">' . e($meta) . '</div>' : '')
        . '</div></div>';
}

/** A quick-action tile on the dashboard. */
function hms_tile(string $iconKey, string $title, string $text, string $href, string $cta): string
{
    return '<a href="' . e($href) . '" class="hms-tile hms-card-hover" style="text-decoration:none;">'
        . '<div class="hms-tile-icon">' . icon($iconKey) . '</div>'
        . '<h5>' . e($title) . '</h5>'
        . '<p>' . e($text) . '</p>'
        . '<span class="btn btn-outline-primary btn-sm" style="pointer-events:none;">' . e($cta) . '</span>'
        . '</a>';
}

function hms_empty(string $iconKey, string $title, string $text = ''): void
{
    echo '<div class="hms-empty">';
    echo '<div class="hms-empty-icon">' . icon($iconKey) . '</div>';
    echo '<h6>' . e($title) . '</h6>';
    if ($text !== '') {
        echo '<p>' . e($text) . '</p>';
    }
    echo '</div>';
}

/** $tabs = [['label' => 'All', 'href' => '...', 'active' => bool], ...] */
function hms_tabs(array $tabs): void
{
    echo '<div class="hms-tabs">';
    foreach ($tabs as $t) {
        $cls = 'hms-tab' . (!empty($t['active']) ? ' is-active' : '');
        echo '<a href="' . e($t['href']) . '" class="' . $cls . '">' . e($t['label']) . '</a>';
    }
    echo '</div>';
}
