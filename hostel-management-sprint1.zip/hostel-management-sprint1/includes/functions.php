<?php

/**
 * Common dial codes for the phone-number inputs, so international students
 * can pick their own country instead of being stuck with a bare digits box.
 * India is first/default since that's where this hostel is based.
 */
function phone_country_codes(): array
{
    return [
        '+91'  => 'India (+91)',
        '+1'   => 'USA/Canada (+1)',
        '+44'  => 'UK (+44)',
        '+61'  => 'Australia (+61)',
        '+971' => 'UAE (+971)',
        '+966' => 'Saudi Arabia (+966)',
        '+65'  => 'Singapore (+65)',
        '+60'  => 'Malaysia (+60)',
        '+977' => 'Nepal (+977)',
        '+880' => 'Bangladesh (+880)',
        '+94'  => 'Sri Lanka (+94)',
        '+92'  => 'Pakistan (+92)',
        '+975' => 'Bhutan (+975)',
        '+95'  => 'Myanmar (+95)',
        '+63'  => 'Philippines (+63)',
        '+27'  => 'South Africa (+27)',
        '+234' => 'Nigeria (+234)',
        '+254' => 'Kenya (+254)',
        '+49'  => 'Germany (+49)',
        '+33'  => 'France (+33)',
        '+81'  => 'Japan (+81)',
        '+86'  => 'China (+86)',
        '+82'  => 'South Korea (+82)',
        '+7'   => 'Russia (+7)',
        '+55'  => 'Brazil (+55)',
    ];
}

/** Split a stored "+<code> <digits>" (or bare legacy "<digits>") value into [code, digits]. */
function split_phone_number(string $value): array
{
    $value = trim($value);
    if ($value !== '' && $value[0] === '+' && preg_match('/^(\+\d{1,4})\s*(.*)$/', $value, $m)) {
        $code = array_key_exists($m[1], phone_country_codes()) ? $m[1] : '+91';
        return [$code, trim($m[2])];
    }
    // Legacy records saved before the country-code selector existed.
    return ['+91', $value];
}

/** Render a country-code select + number input pair sharing one form-control row. */
function phone_input(string $name, string $storedValue, bool $required = true): void
{
    [$code, $digits] = split_phone_number($storedValue);
    ?>
    <div class="hms-phone-input">
      <select name="<?= e($name) ?>_code" class="form-select">
        <?php foreach (phone_country_codes() as $dial => $label): ?>
          <option value="<?= e($dial) ?>" <?= $code === $dial ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
      <input type="text" name="<?= e($name) ?>" class="form-control" value="<?= e($digits) ?>"
             inputmode="numeric" placeholder="9876543210" <?= $required ? 'required' : '' ?>>
    </div>
    <?php
}

function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

/** Escape output for safe HTML display. */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function render_flash(): void
{
    $flash = get_flash();
    if (!$flash) {
        return;
    }
    $cls = $flash['type'] === 'error' ? 'danger' : $flash['type'];
    echo '<div class="alert-banner alert-banner-' . e($cls) . '">' . e($flash['message']) . '</div>';
}

/** Icon-only light/dark theme toggle. $extraClass adds a variant, e.g. 'theme-toggle-btn--sidebar'. */
function theme_toggle_button(string $extraClass = ''): string
{
    $sun = '<svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"></path></svg>';
    $moon = '<svg class="icon-moon" viewBox="0 0 24 24" fill="currentColor"><path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 1020.354 15.354z"></path></svg>';
    $class = trim('theme-toggle-btn theme-toggle ' . $extraClass);
    return '<button type="button" class="' . e($class) . '" aria-label="Toggle dark mode" title="Toggle dark mode">'
        . $sun . $moon . '</button>';
}
