<?php $user = current_user(); ?>
<?php if ($user): ?>
      <footer class="hms-app-footer" style="padding:1.25rem 0 0.5rem;text-align:center;color:var(--h-text-dim);font-size:0.76rem;">
        Bam Bir Hostel Management System &middot; Sprint 1 + Sprint 2 Build
      </footer>
    </main>
  </div>
</div>
<div class="hms-nav-progress" id="hmsNavProgress"></div>
<div class="hms-toast-stack" id="hmsToastStack"></div>
<div class="hms-modal-backdrop" id="hmsConfirmBackdrop">
  <div class="hms-modal">
    <div class="hms-modal-icon" id="hmsConfirmIcon"></div>
    <h4 id="hmsConfirmTitle">Are you sure?</h4>
    <p id="hmsConfirmText">This action cannot be undone.</p>
    <div class="hms-modal-actions">
      <button type="button" class="btn btn-outline-secondary btn-sm" id="hmsConfirmCancel">Cancel</button>
      <button type="button" class="btn btn-outline-danger btn-sm" id="hmsConfirmOk">Confirm</button>
    </div>
  </div>
</div>
<?php else: ?>
</main>
<?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
  // ---------- Legacy (login / register) behaviour — untouched ----------
  var toggle = document.getElementById('sidebarToggle');
  var shell = document.getElementById('appShell');
  if (toggle && shell) {
    toggle.addEventListener('click', function () {
      shell.classList.toggle('sidebar-open');
    });
    shell.addEventListener('click', function (e) {
      if (shell.classList.contains('sidebar-open') && !e.target.closest('.sidebar') && !e.target.closest('#sidebarToggle')) {
        shell.classList.remove('sidebar-open');
      }
    });
  }

  var themeBtn = document.getElementById('themeToggle');
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      var next = isDark ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      try { localStorage.setItem('hms-theme', next); } catch (e) {}
    });
  }

  var clockEl = document.getElementById('liveClock');
  if (clockEl) {
    var fmt = new Intl.DateTimeFormat(undefined, {
      weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
    function tick() { clockEl.textContent = fmt.format(new Date()); }
    tick();
    setInterval(tick, 1000);
  }

  var reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  // ---------- Scroll-reveal (login/register pages) ----------
  // Elements with class="reveal" fade/slide in once they enter the
  // viewport. Siblings inside a [data-reveal-stagger] group get an
  // incremental delay so they animate in one after another rather than
  // all at once (used for the review cards and photo gallery).
  document.querySelectorAll('[data-reveal-stagger]').forEach(function (group) {
    Array.prototype.forEach.call(group.children, function (child, i) {
      child.style.setProperty('--reveal-delay', (i * 0.09) + 's');
    });
  });
  var revealEls = document.querySelectorAll('.reveal');
  if (revealEls.length) {
    if (reduceMotion || !('IntersectionObserver' in window)) {
      revealEls.forEach(function (el) { el.classList.add('is-visible'); });
    } else {
      var revealObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            revealObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
      revealEls.forEach(function (el) { revealObserver.observe(el); });
    }
  }

  function hmsShowNavProgress() {
    var bar = document.getElementById('hmsNavProgress');
    if (bar) bar.classList.add('is-active');
  }

  // Purely visual submit feedback — never prevents or delays the actual
  // submission, just shows a spinner on the clicked button while the
  // browser navigates/posts.
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!(form instanceof HTMLFormElement)) return;
    var btn = form.querySelector('button[type="submit"], input[type="submit"]');
    if (btn) {
      btn.classList.add('is-loading');
    }
    hmsShowNavProgress();
  }, true);

  // ---------- New authenticated app shell ----------
  var app = document.getElementById('hmsApp');
  if (!app) return;

  // Sidebar collapse (desktop)
  var collapseBtn = document.getElementById('hmsCollapseBtn');
  try {
    if (localStorage.getItem('hms-sidebar-collapsed') === '1') {
      app.classList.add('is-collapsed');
    }
  } catch (e) {}
  if (collapseBtn) {
    collapseBtn.addEventListener('click', function () {
      app.classList.toggle('is-collapsed');
      try { localStorage.setItem('hms-sidebar-collapsed', app.classList.contains('is-collapsed') ? '1' : '0'); } catch (e) {}
    });
  }

  // Sidebar open/close (mobile)
  var mobileToggle = document.getElementById('hmsSidebarToggle');
  if (mobileToggle) {
    mobileToggle.addEventListener('click', function (e) {
      e.stopPropagation();
      app.classList.toggle('sidebar-open');
    });
    document.addEventListener('click', function (e) {
      if (app.classList.contains('sidebar-open') && !e.target.closest('.hms-sidebar') && !e.target.closest('#hmsSidebarToggle')) {
        app.classList.remove('sidebar-open');
      }
    });
  }

  // Live clocks (sidebar + topbar)
  var hmsClockFmt = new Intl.DateTimeFormat(undefined, {
    weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
  var sidebarClock = document.getElementById('hmsSidebarClock');
  var topbarClock = document.getElementById('hmsTopbarClock');
  function hmsTick() {
    var text = hmsClockFmt.format(new Date());
    if (sidebarClock) sidebarClock.textContent = text;
    if (topbarClock) topbarClock.textContent = text;
  }
  hmsTick();
  setInterval(hmsTick, 1000);

  // Notification dropdown
  var bell = document.getElementById('hmsNotifBell');
  var dropdown = document.getElementById('hmsNotifDropdown');
  if (bell && dropdown) {
    bell.addEventListener('click', function (e) {
      e.stopPropagation();
      dropdown.classList.toggle('is-open');
    });
    document.addEventListener('click', function (e) {
      if (dropdown.classList.contains('is-open') && !e.target.closest('.hms-notif-wrap')) {
        dropdown.classList.remove('is-open');
      }
    });
  }

  // Flash message -> floating toast (purely presentational; the underlying
  // flash banner markup/content produced by PHP is untouched, this just
  // relocates it into the toast stack and auto-dismisses it).
  var toastStack = document.getElementById('hmsToastStack');
  var flashBanner = document.querySelector('[data-hms-toast]');
  if (toastStack && flashBanner) {
    var tone = flashBanner.getAttribute('data-toast-tone') || 'info';
    var toast = document.createElement('div');
    toast.className = 'hms-toast hms-toast-' + tone;
    var iconSvg = tone === 'success'
      ? '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>'
      : '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>';
    toast.innerHTML = '<span class="hms-toast-icon">' + iconSvg + '</span>'
      + '<span>' + flashBanner.innerHTML + '</span>'
      + '<button type="button" class="hms-toast-close" aria-label="Dismiss">&times;</button>';
    toastStack.appendChild(toast);
    flashBanner.remove();
    var removeToast = function () {
      toast.classList.add('is-leaving');
      setTimeout(function () { toast.remove(); }, 220);
    };
    toast.querySelector('.hms-toast-close').addEventListener('click', removeToast);
    setTimeout(removeToast, 5000);
  }

  // Generic confirm modal — replaces native confirm() dialogs for a more
  // polished experience. Forms opt in with data-confirm-title / data-confirm-text;
  // the original action/method/fields are submitted unchanged on confirm.
  var confirmBackdrop = document.getElementById('hmsConfirmBackdrop');
  var confirmTitleEl = document.getElementById('hmsConfirmTitle');
  var confirmTextEl = document.getElementById('hmsConfirmText');
  var confirmOkBtn = document.getElementById('hmsConfirmOk');
  var confirmCancelBtn = document.getElementById('hmsConfirmCancel');
  var pendingForm = null;

  function openConfirm(form) {
    pendingForm = form;
    confirmTitleEl.textContent = form.getAttribute('data-confirm-title') || 'Are you sure?';
    confirmTextEl.textContent = form.getAttribute('data-confirm-text') || 'This action cannot be undone.';
    confirmBackdrop.classList.add('is-open');
  }
  function closeConfirm() {
    confirmBackdrop.classList.remove('is-open');
    pendingForm = null;
  }
  if (confirmBackdrop) {
    document.addEventListener('submit', function (e) {
      var form = e.target;
      if (!(form instanceof HTMLFormElement)) return;
      if (form.hasAttribute('data-confirm') && !form.hasAttribute('data-confirmed')) {
        e.preventDefault();
        openConfirm(form);
      }
    });
    confirmCancelBtn.addEventListener('click', closeConfirm);
    confirmBackdrop.addEventListener('click', function (e) {
      if (e.target === confirmBackdrop) closeConfirm();
    });
    confirmOkBtn.addEventListener('click', function () {
      if (pendingForm) {
        pendingForm.setAttribute('data-confirmed', '1');
        var btn = pendingForm.querySelector('button[type="submit"], input[type="submit"]');
        if (btn) btn.classList.add('is-loading');
        confirmBackdrop.classList.remove('is-open');
        pendingForm.submit();
      }
    });
  }

  // Generic table search + client-side pagination.
  // Markup convention:
  //   <div data-hms-table>
  //     <input data-hms-search> ... <span data-hms-count></span>
  //     <tbody data-hms-rows>...rows...</tbody>
  //     <div data-hms-pagination data-page-size="10"></div>
  //   </div>
  document.querySelectorAll('[data-hms-table]').forEach(function (wrap) {
    var search = wrap.querySelector('[data-hms-search]');
    var rowsBody = wrap.querySelector('[data-hms-rows]');
    var countEl = wrap.querySelector('[data-hms-count]');
    var pager = wrap.querySelector('[data-hms-pagination]');
    if (!rowsBody) return;
    var pageSize = pager ? parseInt(pager.getAttribute('data-page-size') || '8', 10) : 999999;
    var allRows = Array.prototype.slice.call(rowsBody.querySelectorAll('tr[data-row]'));
    var page = 1;

    function apply() {
      var q = (search && search.value ? search.value : '').trim().toLowerCase();
      var matches = allRows.filter(function (row) {
        return !q || row.textContent.toLowerCase().indexOf(q) !== -1;
      });
      var totalPages = Math.max(1, Math.ceil(matches.length / pageSize));
      if (page > totalPages) page = totalPages;

      allRows.forEach(function (row) { row.style.display = 'none'; });
      matches.slice((page - 1) * pageSize, page * pageSize).forEach(function (row, i) {
        row.style.display = '';
        row.style.setProperty('--hms-i', i);
      });

      if (countEl) {
        countEl.textContent = matches.length === 0
          ? 'No matching rows'
          : ('Showing ' + (matches.length === 0 ? 0 : ((page - 1) * pageSize + 1)) + '\u2013' + Math.min(page * pageSize, matches.length) + ' of ' + matches.length);
      }

      var emptyRow = wrap.querySelector('[data-hms-empty]');
      if (emptyRow) emptyRow.style.display = matches.length === 0 ? '' : 'none';

      if (pager) {
        pager.innerHTML = '';
        if (totalPages > 1) {
          var btns = document.createElement('div');
          btns.className = 'hms-pagination-btns';
          var prev = document.createElement('button');
          prev.type = 'button'; prev.textContent = '\u2039';
          prev.disabled = page === 1;
          prev.addEventListener('click', function () { page--; apply(); });
          btns.appendChild(prev);
          for (var p = 1; p <= totalPages; p++) {
            (function (p) {
              var b = document.createElement('button');
              b.type = 'button'; b.textContent = String(p);
              if (p === page) b.classList.add('is-active');
              b.addEventListener('click', function () { page = p; apply(); });
              btns.appendChild(b);
            })(p);
          }
          var next = document.createElement('button');
          next.type = 'button'; next.textContent = '\u203a';
          next.disabled = page === totalPages;
          next.addEventListener('click', function () { page++; apply(); });
          btns.appendChild(next);
          pager.appendChild(btns);
        }
      }
    }

    if (search) {
      search.addEventListener('input', function () { page = 1; apply(); });
    }
    apply();
  });

  // ---------- Staggered entrance for grids of cards ----------
  function hmsStagger(selector) {
    document.querySelectorAll(selector).forEach(function (group) {
      Array.prototype.forEach.call(group.children, function (child, i) {
        child.style.setProperty('--hms-i', i);
      });
    });
  }
  hmsStagger('.hms-stat-grid');
  hmsStagger('.hms-tile-grid');
  hmsStagger('.hms-room-grid');
  hmsStagger('.hms-feed');

  // ---------- Skeleton loader: brief perceived-loading flash on first paint ----------
  // The page is already fully rendered server-side, so this is a short,
  // purely cosmetic veil that gives the same "data is loading in" feel a
  // premium dashboard has, without ever hiding real content for long.
  (function () {
    var content = document.querySelector('.hms-content');
    if (!content || reduceMotion) return;
    var veil = document.createElement('div');
    veil.className = 'hms-skeleton-veil';
    veil.innerHTML =
      '<div class="hms-skeleton-block" style="height:2.2rem;width:40%;"></div>' +
      '<div class="hms-skeleton-row">' +
        '<div class="hms-skeleton-block" style="height:80px;flex:1;"></div>' +
        '<div class="hms-skeleton-block" style="height:80px;flex:1;"></div>' +
        '<div class="hms-skeleton-block" style="height:80px;flex:1;"></div>' +
        '<div class="hms-skeleton-block" style="height:80px;flex:1;"></div>' +
      '</div>' +
      '<div class="hms-skeleton-block" style="height:220px;width:100%;"></div>';
    content.prepend(veil);
    setTimeout(function () {
      veil.classList.add('is-hidden');
      setTimeout(function () { veil.remove(); }, 320);
    }, 260);
  })();

  // ---------- Animated progress bars + donut charts ----------
  function hmsAnimateFills() {
    document.querySelectorAll('[data-target]').forEach(function (el) {
      var target = el.getAttribute('data-target');
      requestAnimationFrame(function () {
        requestAnimationFrame(function () { el.style.width = target + '%'; });
      });
    });
    document.querySelectorAll('[data-target-offset]').forEach(function (el) {
      var target = el.getAttribute('data-target-offset');
      requestAnimationFrame(function () {
        requestAnimationFrame(function () { el.style.strokeDashoffset = target; });
      });
    });
  }
  hmsAnimateFills();

  // ---------- Soft page transitions on internal navigation ----------
  // Purely a fade+slide exit before the browser follows the link/form — the
  // destination URL, method, and all fields are completely untouched.
  var contentEl = document.querySelector('.hms-content');
  function hmsNavigateWithTransition(url) {
    hmsShowNavProgress();
    if (reduceMotion || !contentEl) { window.location = url; return; }
    contentEl.classList.add('is-leaving');
    setTimeout(function () { window.location = url; }, 140);
  }
  document.querySelectorAll('.hms-sidebar a[href], .hms-content a[href]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var href = a.getAttribute('href');
      if (!href || href.charAt(0) === '#') return;
      if (a.target === '_blank' || a.hasAttribute('download')) return;
      if (href.indexOf('mailto:') === 0 || href.indexOf('tel:') === 0) return;
      if (e.defaultPrevented || e.button !== 0) return;
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var url;
      try { url = new URL(href, window.location.href); } catch (err) { return; }
      if (url.origin !== window.location.origin) return;
      e.preventDefault();
      hmsNavigateWithTransition(url.href);
    });
  });

})();
</script>
</body>
</html>
