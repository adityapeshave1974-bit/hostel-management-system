<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function require_login(): void
{
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

/**
 * Restrict a page to one or more roles. Redirects (rather than blank-403s)
 * so a logged-in user landing on the wrong module just bounces to their
 * own dashboard instead of hitting a dead end.
 */
function require_role($roles): void
{
    require_login();
    $roles = (array) $roles;
    if (!in_array($_SESSION['role'], $roles, true)) {
        redirect('dashboard.php');
    }
}

function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    return [
        'id'         => $_SESSION['user_id'],
        'username'   => $_SESSION['username'],
        'role'       => $_SESSION['role'],
        'full_name'  => $_SESSION['full_name'],
        'student_id' => $_SESSION['student_id'] ?? null,
    ];
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(400);
        die('Invalid or expired form submission. Please go back and try again.');
    }
}

/**
 * A small self-hosted CAPTCHA — no external service or API key required.
 * Generates a fresh "a + b" question, stores the answer in the session,
 * and is re-generated every time the form is (re)rendered.
 */
function new_captcha(): array
{
    $a = random_int(1, 9);
    $b = random_int(1, 9);
    $_SESSION['captcha_a'] = $a;
    $_SESSION['captcha_b'] = $b;
    return [$a, $b];
}

function verify_captcha(string $answer): bool
{
    $expected = ($_SESSION['captcha_a'] ?? null) + ($_SESSION['captcha_b'] ?? null);
    $ok = isset($_SESSION['captcha_a'], $_SESSION['captcha_b']) && ((int) trim($answer) === $expected);
    unset($_SESSION['captcha_a'], $_SESSION['captcha_b']);
    return $ok;
}
