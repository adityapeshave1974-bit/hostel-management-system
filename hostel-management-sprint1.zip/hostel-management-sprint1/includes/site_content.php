<?php
// Edit the arrays below to update what shows on the login/register screens.
// These are sample placeholders — swap in your real facts and real guest
// reviews before this goes live.

define('CONTACT_NAME', 'AdiOP');
define('CONTACT_PHONE', '+91 6162696969');

// Address shown under "Find us" and used to build the map embed/link below.
// Swap in the hostel's real address — the two map URLs are just a Google
// Maps search query, no API key required.
define('MAP_ADDRESS', 'Bir, Himachal Pradesh 176077, India');
define('MAP_EMBED_URL', 'https://www.google.com/maps?q=' . rawurlencode(MAP_ADDRESS) . '&output=embed');
define('MAP_LINK_URL', 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(MAP_ADDRESS));

// Social links shown on the login page. Set a handle to '' to hide that icon.
$SOCIAL_LINKS = [
    ['name' => 'Instagram', 'icon' => 'instagram', 'url' => 'https://instagram.com/bambirhostel'],
    ['name' => 'X',         'icon' => 'x-twitter', 'url' => 'https://x.com/bambirhostel'],
    ['name' => 'Facebook',  'icon' => 'facebook',  'url' => 'https://facebook.com/bambirhostel'],
    ['name' => 'WhatsApp',  'icon' => 'whatsapp',  'url' => 'https://wa.me/916162696969'],
];

$HOSTEL_FACTS = [
    'Just 10 minutes from the Bir Billing paragliding takeoff point.',
    'Free high-speed WiFi in every room and common area.',
    '24x7 warden support with a CCTV-monitored campus.',
    'Rooftop lounge with mountain views, open till midnight.',
    'Home-style meals included with every stay.',
    'Walking distance to Bir\'s cafes and local market.',
];

// Sample reviews — replace names and quotes with real guest feedback.
$HOSTEL_REVIEWS = [
    ['name' => 'Ananya R.', 'rating' => 5, 'quote' => 'Best hostel stay in Bir, hands down. The rooftop view alone is worth it.'],
    ['name' => 'Karan M.',  'rating' => 5, 'quote' => 'Clean rooms, friendly staff, and the paragliding pickup was so convenient.'],
    ['name' => 'Priya S.',  'rating' => 4, 'quote' => 'Great vibe, met so many fellow travelers here. Would stay again.'],
];

// Photo gallery shown on the login page. Rooftop/pool/rooms/common area
// use real photos now — exterior still points at the placeholder
// assets/images/hostel.jpg until a real shot of that is added.
$HOSTEL_GALLERY = [
    ['src' => 'assets/images/gallery-rooftop.jpg', 'caption' => 'Rooftop lounge & mountain views'],
    ['src' => 'assets/images/gallery-pool.jpg', 'caption' => 'Swimming pool with mountain views'],
    ['src' => 'assets/images/gallery-room.jpg', 'caption' => 'Cozy shared dorm rooms'],
    ['src' => 'assets/images/gallery-common.webp', 'caption' => 'Common area & hangout space'],
    ['src' => 'assets/images/gallery-4.jpg', 'caption' => 'Exterior & entrance'],
];
