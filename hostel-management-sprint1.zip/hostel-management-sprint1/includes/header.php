<?php
// Expects $pageTitle to optionally be set by the including page.
require_once __DIR__ . '/notifications.php';
require_once __DIR__ . '/ui.php';

$user = current_user();
$pageTitle = $pageTitle ?? 'Hostel Management System';
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$notifications = ($user && isset($pdo)) ? get_notifications($pdo, $user) : [];

// Small inline icon set so the sidebar doesn't depend on an external icon font.
function icon($name) {
    $icons = [
        'dashboard'  => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>',
        'students'   => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
        'rooms'      => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-6h6v6"/></svg>',
        'fees'       => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v10M9 9.5c0-1.4 1.3-2.5 3-2.5s3 .9 3 2.2-1.3 2-3 2.3-3 1-3 2.3S10.6 16 12 16s3-.9 3-2.3"/></svg>',
        'complaints' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M12 8v4M12 15h.01"/></svg>',
        'notices'    => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
        'reports'    => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 15l4-6 4 3 5-7"/></svg>',
        'bell'       => '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
        'sun'        => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>',
        'moon'       => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>',
        'instagram'  => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><path d="M17.5 6.5h.01"/></svg>',
        'x-twitter'  => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M18.24 2.75h3.34l-7.3 8.34 8.59 11.16h-6.73l-5.27-6.9-6.03 6.9H1.5l7.8-8.92L1.06 2.75h6.9l4.77 6.3zm-1.17 17.4h1.85L7.02 4.66H5.03z"/></svg>',
        'facebook'   => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M13.5 21v-7.9h2.66l.4-3.1h-3.06V8.1c0-.9.25-1.5 1.55-1.5h1.65V3.8c-.29-.04-1.27-.12-2.4-.12-2.4 0-4.03 1.46-4.03 4.14v2.3H7.6v3.1h2.67V21z"/></svg>',
        'whatsapp'   => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12.02 2c-5.5 0-9.96 4.46-9.96 9.96 0 1.76.46 3.48 1.34 5L2 22l5.2-1.36a9.94 9.94 0 0 0 4.82 1.23h.01c5.5 0 9.96-4.46 9.96-9.96S17.52 2 12.02 2zm5.83 14.24c-.25.7-1.24 1.28-2.02 1.44-.55.12-1.26.21-3.66-.79-3.07-1.27-5.05-4.39-5.2-4.6-.15-.2-1.24-1.65-1.24-3.15 0-1.5.78-2.23 1.06-2.54.28-.3.6-.38.81-.38.2 0 .41 0 .59.01.19.01.44-.07.69.53.25.6.86 2.08.94 2.23.08.15.13.33.03.53-.1.2-.15.33-.3.5-.15.18-.31.4-.44.53-.15.15-.3.31-.13.6.17.3.76 1.26 1.64 2.04 1.13.99 2.07 1.31 2.37 1.46.3.15.48.13.65-.08.18-.2.75-.87.95-1.17.2-.3.4-.25.66-.15.28.1 1.76.83 2.06.98.3.15.5.23.57.35.08.13.08.75-.17 1.46z"/></svg>',
        'map-pin'    => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
        'external'   => '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14 21 3"/></svg>',
        'chevrons-left' => '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 17l-5-5 5-5M18 17l-5-5 5-5"/></svg>',
        'menu'       => '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h18M3 6h18M3 18h18"/></svg>',
        'search'     => '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>',
        'plus'       => '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>',
        'wallet'     => '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h3v-4z"/></svg>',
        'building'   => '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"/><path d="M9 9h1M14 9h1M9 13h1M14 13h1M9 17h1M14 17h1"/></svg>',
        'bed'        => '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8"/><path d="M2 16h20"/><path d="M6 12V7a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3"/><path d="M2 20v1M22 20v1"/></svg>',
        'user-check' => '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M16 11l2 2 4-4"/></svg>',
        'activity'   => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
        'alert'      => '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>',
        'check-circle' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>',
        'x-close'    => '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>',
        'user-plus'  => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>',
        'file-text'  => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h6M9 17h6M9 9h1"/></svg>',
        'door'       => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="1"/><circle cx="14" cy="12" r="1" fill="currentColor" stroke="none"/></svg>',
        'log-out'    => '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>',
        'arrow-left' => '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>',
    ];
    return $icons[$name] ?? '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> &middot; Bam Bir Hostel</title>
<script>
// Applied before CSS loads, so the page never flashes the wrong theme.
(function () {
  try {
    var saved = localStorage.getItem('hms-theme');
    document.documentElement.setAttribute('data-theme', saved === 'dark' ? 'dark' : 'light');
  } catch (e) {}
})();
</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Work+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css?v=<?= @filemtime(__DIR__ . '/../assets/css/style.css') ?: time() ?>" rel="stylesheet">
<?php if ($user): ?>
<link href="assets/css/hms-app.css?v=<?= @filemtime(__DIR__ . '/../assets/css/hms-app.css') ?: time() ?>" rel="stylesheet">
<?php endif; ?>
<noscript><style>.reveal { opacity: 1 !important; transform: none !important; }</style></noscript>
</head>
<body>
<?php if ($user): ?>
<?php
// role -> ordered list of [href, matching pages, icon key, label], so the active-state
// matching and markup below stay in one place instead of being duplicated per role.
$navByRole = [
    'admin' => [
        ['admin_dashboard.php', ['admin_dashboard.php'], 'dashboard', 'Dashboard'],
        ['admin_students.php', ['admin_students.php', 'admin_student_form.php'], 'students', 'Students'],
        ['admin_rooms.php', ['admin_rooms.php', 'admin_room_form.php', 'admin_room_manage.php'], 'rooms', 'Rooms'],
        ['admin_fees.php', ['admin_fees.php', 'admin_fee_form.php'], 'fees', 'Fees'],
        ['staff_complaints.php', ['staff_complaints.php'], 'complaints', 'Complaints'],
        ['notices.php', ['notices.php'], 'notices', 'Notices'],
        ['admin_reports.php', ['admin_reports.php'], 'reports', 'Reports'],
    ],
    'warden' => [
        ['warden_dashboard.php', ['warden_dashboard.php'], 'dashboard', 'Dashboard'],
        ['warden_approvals.php', ['warden_approvals.php'], 'user-check', 'Approvals'],
        ['staff_complaints.php', ['staff_complaints.php'], 'complaints', 'Complaints'],
        ['notices.php', ['notices.php'], 'notices', 'Notices'],
    ],
    'student' => [
        ['student_dashboard.php', ['student_dashboard.php'], 'dashboard', 'My Dashboard'],
        ['student_fees.php', ['student_fees.php'], 'fees', 'My Fees'],
        ['student_complaints.php', ['student_complaints.php', 'student_complaint_new.php'], 'complaints', 'My Complaints'],
        ['notices.php', ['notices.php'], 'notices', 'Notices'],
    ],
];
$navItems = $navByRole[$user['role']] ?? [];
?>
<div class="hms-app" id="hmsApp">
  <aside class="hms-sidebar">
    <div class="hms-sidebar-brand">
      <span class="hms-brand-mark">BB</span>
      <div class="hms-brand-text">
        <div class="hms-brand-name">Bam Bir Hostel</div>
        <div class="hms-brand-sub">Management System</div>
      </div>
      <button type="button" class="hms-sidebar-collapse-btn" id="hmsCollapseBtn" aria-label="Collapse sidebar">
        <?= icon('chevrons-left') ?>
      </button>
    </div>
    <div class="hms-sidebar-clock" id="hmsSidebarClock">&nbsp;</div>
    <nav class="hms-sidebar-nav">
      <?php foreach ($navItems as [$href, $matches, $iconKey, $label]):
        $isActive = in_array($currentPage, $matches, true);
      ?>
        <a href="<?= e($href) ?>" class="hms-nav-link<?= $isActive ? ' is-active' : '' ?>">
          <?= icon($iconKey) ?><span><?= e($label) ?></span>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="hms-sidebar-footer">
      <div class="hms-user-chip">
        <div class="hms-user-avatar"><?= e(strtoupper(substr($user['full_name'], 0, 1))) ?></div>
        <div class="hms-user-meta">
          <div class="hms-user-name"><?= e($user['full_name']) ?></div>
          <div class="hms-user-role"><?= e($user['role']) ?></div>
        </div>
      </div>
      <div class="hms-sidebar-actions">
        <a href="logout.php" class="hms-logout-btn"><?= icon('log-out') ?><span>Log out</span></a>
        <button type="button" class="hms-theme-btn" id="themeToggle" aria-label="Toggle light / dark theme">
          <span class="hms-icon-sun"><?= icon('sun') ?></span>
          <span class="hms-icon-moon"><?= icon('moon') ?></span>
        </button>
      </div>
    </div>
  </aside>

  <div class="hms-main">
    <div class="hms-mobile-bar">
      <button type="button" class="hms-hamburger" id="hmsSidebarToggle" aria-label="Toggle menu"><?= icon('menu') ?></button>
      <span class="hms-mobile-brand">Bam Bir Hostel</span>
    </div>

    <div class="hms-topbar">
      <div class="hms-topbar-title-wrap">
        <div class="hms-topbar-eyebrow"><?= e(ucfirst($user['role'])) ?> workspace</div>
        <div class="hms-topbar-title"><?= e($pageTitle) ?></div>
      </div>
      <div class="hms-topbar-right">
        <div class="hms-topbar-clock" id="hmsTopbarClock">&nbsp;</div>
        <div class="hms-notif-wrap">
          <button type="button" class="hms-notif-bell" id="hmsNotifBell" aria-label="Notifications">
            <?= icon('bell') ?>
            <?php if ($notifications): ?>
              <span class="hms-notif-badge"><?= count($notifications) > 9 ? '9+' : count($notifications) ?></span>
            <?php endif; ?>
          </button>
          <div class="hms-notif-dropdown" id="hmsNotifDropdown">
            <div class="hms-notif-dropdown-title">Notifications</div>
            <?php if (!$notifications): ?>
              <div class="hms-notif-empty">You're all caught up.</div>
            <?php else: ?>
              <?php foreach ($notifications as $n): ?>
                <a href="<?= e($n['link']) ?>" class="hms-notif-item">
                  <div class="hms-notif-meta"><?= e($n['meta']) ?></div>
                  <div class="hms-notif-text"><?= $n['text'] /* already escaped where built */ ?></div>
                </a>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
        <div class="hms-user-menu-btn">
          <div class="hms-user-menu-avatar"><?= e(strtoupper(substr($user['full_name'], 0, 1))) ?></div>
          <span class="hms-user-menu-name"><?= e($user['full_name']) ?></span>
        </div>
      </div>
    </div>

    <main class="hms-content">
      <?php $flash = get_flash(); if ($flash):
          $cls = $flash['type'] === 'error' ? 'danger' : $flash['type'];
      ?>
        <div class="alert-banner alert-banner-<?= e($cls) ?>" data-hms-toast data-toast-tone="<?= e($cls) ?>"><?= e($flash['message']) ?></div>
      <?php endif; ?>
<?php else: ?>
<main class="auth-page">
  <div class="auth-page-topbar">
    <div class="live-clock" id="liveClock">&nbsp;</div>
    <button type="button" class="theme-toggle-btn theme-toggle-floating" id="themeToggle" aria-label="Toggle dark mode">
      <span class="icon-sun"><?= icon('sun') ?></span>
      <span class="icon-moon"><?= icon('moon') ?></span>
    </button>
  </div>
<?php endif; ?>
