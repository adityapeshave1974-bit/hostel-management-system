<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

$roomId = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM rooms WHERE room_id = ?');
$stmt->execute([$roomId]);
$room = $stmt->fetch();

if (!$room) {
    set_flash('error', 'Room not found.');
    redirect('admin_rooms.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'allocate') {
        $studentId = (int) ($_POST['student_id'] ?? 0);
        $available = $room['capacity'] - $room['occupied_beds'];

        if ($available <= 0) {
            set_flash('error', 'This room has no available beds.');
        } else {
            // Re-check the student is still free (guards against a race
            // between two admins allocating at the same time).
            $check = $pdo->prepare('SELECT COUNT(*) FROM room_allocations WHERE student_id = ? AND vacated_date IS NULL');
            $check->execute([$studentId]);
            if ((int) $check->fetchColumn() > 0) {
                set_flash('error', 'That student already has an active room allocation.');
            } else {
                $pdo->beginTransaction();
                $ins = $pdo->prepare(
                    'INSERT INTO room_allocations (student_id, room_id, allocated_date) VALUES (?, ?, CURDATE())'
                );
                $ins->execute([$studentId, $roomId]);
                $upd = $pdo->prepare('UPDATE rooms SET occupied_beds = occupied_beds + 1 WHERE room_id = ?');
                $upd->execute([$roomId]);
                $pdo->commit();
                set_flash('success', 'Student allocated to this room.');
            }
        }
    } elseif ($action === 'vacate') {
        $allocationId = (int) ($_POST['allocation_id'] ?? 0);

        $pdo->beginTransaction();
        $upd = $pdo->prepare(
            'UPDATE room_allocations SET vacated_date = CURDATE()
             WHERE id = ? AND room_id = ? AND vacated_date IS NULL'
        );
        $upd->execute([$allocationId, $roomId]);

        if ($upd->rowCount() > 0) {
            $pdo->prepare('UPDATE rooms SET occupied_beds = GREATEST(occupied_beds - 1, 0) WHERE room_id = ?')
                ->execute([$roomId]);
            $pdo->commit();
            set_flash('success', 'Student vacated from this room.');
        } else {
            $pdo->rollBack();
            set_flash('error', 'That allocation was not found or already vacated.');
        }
    }

    redirect('admin_room_manage.php?id=' . $roomId);
}

// Refresh room after any POST.
$stmt = $pdo->prepare('SELECT * FROM rooms WHERE room_id = ?');
$stmt->execute([$roomId]);
$room = $stmt->fetch();

$occupants = $pdo->prepare(
    "SELECT ra.id AS allocation_id, ra.allocated_date, s.student_id, s.name, s.department, s.mobile
     FROM room_allocations ra
     JOIN students s ON s.student_id = ra.student_id
     WHERE ra.room_id = ? AND ra.vacated_date IS NULL
     ORDER BY ra.allocated_date"
);
$occupants->execute([$roomId]);
$occupants = $occupants->fetchAll();

$availableStudents = $pdo->prepare(
    "SELECT student_id, name, department FROM students
     WHERE student_id NOT IN (
       SELECT student_id FROM room_allocations WHERE vacated_date IS NULL
     )
     ORDER BY name"
);
$availableStudents->execute();
$availableStudents = $availableStudents->fetchAll();

$available = $room['capacity'] - $room['occupied_beds'];

$pageTitle = 'Manage Room ' . $room['room_no'];
require 'includes/header.php';
?>

<?php
hms_page_head(
    'Room ' . $room['room_no'],
    e($room['block']) . ' &middot; Floor ' . e($room['floor']),
    '<a href="admin_rooms.php" class="btn btn-outline-secondary btn-sm">' . icon('arrow-left') . ' Back to Rooms</a>'
);
?>

<div class="hms-stat-grid hms-stat-grid-3">
  <?= hms_stat('Capacity', (string) (int) $room['capacity'], 'bed') ?>
  <?= hms_stat('Occupied', (string) (int) $room['occupied_beds'], 'user-check', 'danger') ?>
  <?= hms_stat('Available', (string) (int) $available, 'door', 'success') ?>
</div>

<div class="hms-grid-7-5">
  <div class="hms-card hms-card-pad">
    <div class="hms-section-title"><h5><?= icon('students') ?> Current Occupants</h5></div>
    <?php if (!$occupants): ?>
      <?php hms_empty('students', 'No occupants yet', 'Allocate a student to this room using the panel on the right.'); ?>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead><tr><th>Student</th><th>Department</th><th>Since</th><th></th></tr></thead>
          <tbody>
            <?php foreach ($occupants as $o): ?>
              <tr>
                <td><?= e($o['name']) ?> <span style="color:var(--h-text-dim);">#<?= (int) $o['student_id'] ?></span></td>
                <td><?= e($o['department']) ?></td>
                <td><?= e($o['allocated_date']) ?></td>
                <td class="text-end">
                  <form method="post" data-confirm data-confirm-title="Vacate this student?"
                        data-confirm-text="<?= e($o['name']) ?> will be removed from Room <?= e($room['room_no']) ?>.">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="vacate">
                    <input type="hidden" name="allocation_id" value="<?= (int) $o['allocation_id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger">Vacate</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="hms-card hms-card-pad">
    <div class="hms-section-title"><h5><?= icon('user-plus') ?> Allocate a Student</h5></div>
    <?php if ($available <= 0): ?>
      <?php hms_empty('door', 'Room is full', 'Vacate a bed before allocating a new student.'); ?>
    <?php elseif (!$availableStudents): ?>
      <?php hms_empty('students', 'Everyone is housed', 'Every student already has a room. Add more students first.'); ?>
    <?php else: ?>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="allocate">
        <div class="mb-3">
          <label class="form-label">Student</label>
          <select name="student_id" class="form-select" required>
            <option value="">Select a student&hellip;</option>
            <?php foreach ($availableStudents as $s): ?>
              <option value="<?= (int) $s['student_id'] ?>">
                <?= e($s['name']) ?> &mdash; #<?= (int) $s['student_id'] ?> (<?= e($s['department']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="btn btn-primary"><?= icon('check-circle') ?> Allocate</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
