<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

$totalStudents = $pdo->query('SELECT COUNT(*) FROM students')->fetchColumn();
$totalRooms    = $pdo->query('SELECT COUNT(*) FROM rooms')->fetchColumn();
$capacitySum   = (int) $pdo->query('SELECT COALESCE(SUM(capacity),0) FROM rooms')->fetchColumn();
$occupiedSum   = (int) $pdo->query('SELECT COALESCE(SUM(occupied_beds),0) FROM rooms')->fetchColumn();
$availableSum  = max(0, $capacitySum - $occupiedSum);
$pendingComplaints = (int) $pdo->query("SELECT COUNT(*) FROM complaints WHERE status='Pending'")->fetchColumn();
$pendingFees       = (float) $pdo->query("SELECT COALESCE(SUM(amount),0) FROM fees WHERE status='Pending'")->fetchColumn();

// Read-only, presentation-only queries for the new dashboard's room overview
// and activity feed — no business logic, schema, or write paths touched.
$roomOverview = $pdo->query('SELECT * FROM rooms ORDER BY block, room_no LIMIT 8')->fetchAll();

$feed = [];
$recentStudents = $pdo->query('SELECT name, created_at FROM students ORDER BY created_at DESC LIMIT 4')->fetchAll();
foreach ($recentStudents as $r) {
    $feed[] = ['icon' => 'user-plus', 'text' => e($r['name']) . ' was added as a student', 'time' => $r['created_at']];
}
$recentFees = $pdo->query(
    "SELECT f.amount, f.paid_date, s.name FROM fees f JOIN students s ON s.student_id = f.student_id
     WHERE f.status='Paid' ORDER BY f.paid_date DESC LIMIT 4"
)->fetchAll();
foreach ($recentFees as $r) {
    $feed[] = ['icon' => 'check-circle', 'text' => e($r['name']) . ' paid &#8377;' . number_format((float) $r['amount']), 'time' => $r['paid_date']];
}
$recentComplaints = $pdo->query(
    "SELECT c.subject, c.created_at, s.name FROM complaints c JOIN students s ON s.student_id = c.student_id
     ORDER BY c.created_at DESC LIMIT 4"
)->fetchAll();
foreach ($recentComplaints as $r) {
    $feed[] = ['icon' => 'alert', 'text' => e($r['name']) . ' filed &ldquo;' . e($r['subject']) . '&rdquo;', 'time' => $r['created_at']];
}
usort($feed, fn($a, $b) => strcmp((string) $b['time'], (string) $a['time']));
$feed = array_slice($feed, 0, 6);

$pageTitle = 'Admin Dashboard';
require 'includes/header.php';
?>

<div class="hms-page-head">
  <div>
    <h1 class="hms-page-title">Welcome back, <?= e(explode(' ', $_SESSION['full_name'])[0]) ?></h1>
    <p class="hms-page-subtitle">Here&rsquo;s what&rsquo;s happening across the hostel today.</p>
  </div>
  <div class="hms-page-actions">
    <a href="admin_student_form.php" class="btn btn-outline-primary btn-sm"><?= icon('plus') ?> Add Student</a>
    <a href="admin_room_form.php" class="btn btn-primary btn-sm"><?= icon('plus') ?> Add Room</a>
  </div>
</div>

<div class="hms-stat-grid">
  <?= hms_stat('Total Students', (string) (int) $totalStudents, 'students') ?>
  <?= hms_stat('Total Rooms', (string) (int) $totalRooms, 'building', 'violet') ?>
  <?= hms_stat('Occupied Beds', (string) $occupiedSum, 'bed', 'danger') ?>
  <?= hms_stat('Available Beds', (string) $availableSum, 'door', 'success') ?>
</div>

<div class="hms-grid-7-5">
  <div>
    <div class="hms-section-title"><h5><?= icon('building') ?> Room Occupancy Overview</h5>
      <a href="admin_rooms.php" class="btn btn-outline-secondary btn-sm">View all rooms</a>
    </div>
    <?php if (!$roomOverview): ?>
      <div class="hms-card hms-card-pad">
        <?php hms_empty('building', 'No rooms yet', 'Add your first room to see occupancy here.'); ?>
      </div>
    <?php else: ?>
      <div class="hms-room-grid">
        <?php foreach ($roomOverview as $r):
          $pct = $r['capacity'] > 0 ? min(100, round(($r['occupied_beds'] / $r['capacity']) * 100)) : 0;
        ?>
          <div class="hms-room-chip">
            <div class="hms-room-chip-head">
              <span class="door-plate"><?= e($r['room_no']) ?></span>
              <span style="font-size:0.72rem;color:var(--h-text-dim);"><?= e($r['block']) ?></span>
            </div>
            <div class="hms-room-bar"><div class="hms-room-bar-fill" data-target="<?= $pct ?>" style="width:0%;"></div></div>
            <div class="hms-room-chip-foot">
              <span><?= (int) $r['occupied_beds'] ?>/<?= (int) $r['capacity'] ?> beds</span>
              <span><?= $pct ?>%</span>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="hms-section-title" style="margin-top:1.5rem;"><h5><?= icon('bell') ?> Quick Actions</h5></div>
    <div class="hms-tile-grid">
      <?= hms_tile('students', 'Students', 'Add, edit, search, or remove student records.', 'admin_students.php', 'Manage Students') ?>
      <?= hms_tile('rooms', 'Rooms', 'Allocate students to beds or vacate rooms.', 'admin_rooms.php', 'Manage Rooms') ?>
      <?= hms_tile('wallet', 'Fees', '&#8377;' . number_format($pendingFees) . ' currently pending.', 'admin_fees.php', 'Manage Fees') ?>
      <?= hms_tile('complaints', 'Complaints', $pendingComplaints . ' complaint' . ($pendingComplaints === 1 ? '' : 's') . ' waiting on a response.', 'staff_complaints.php', 'Review Complaints') ?>
      <?= hms_tile('notices', 'Notices', 'Post announcements visible to wardens and students.', 'notices.php', 'Go to Notices') ?>
      <?= hms_tile('reports', 'Reports', 'Student, occupancy, fee, and complaint reports.', 'admin_reports.php', 'View Reports') ?>
    </div>
  </div>

  <div>
    <div class="hms-section-title"><h5><?= icon('activity') ?> Activity Feed</h5></div>
    <div class="hms-card hms-card-pad">
      <?php if (!$feed): ?>
        <?php hms_empty('activity', 'Nothing yet', 'Recent activity across the hostel will show up here.'); ?>
      <?php else: ?>
        <div class="hms-feed">
          <?php foreach ($feed as $item): ?>
            <?= hms_feed_item($item['icon'], $item['text'], $item['time'] ? e($item['time']) : '') ?>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
