<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin_fees.php');
}
verify_csrf();

$feeId = (int) ($_POST['fee_id'] ?? 0);
$mode  = trim($_POST['mode'] ?? '');

if ($mode === '') {
    set_flash('error', 'Please select a payment mode.');
    redirect('admin_fees.php');
}

$stmt = $pdo->prepare("UPDATE fees SET status='Paid', paid_date=CURDATE(), mode=? WHERE fee_id=? AND status='Pending'");
$stmt->execute([$mode, $feeId]);

if ($stmt->rowCount() > 0) {
    set_flash('success', 'Payment recorded.');
} else {
    set_flash('error', 'That fee record was not found or is already marked paid.');
}

redirect('admin_fees.php');
