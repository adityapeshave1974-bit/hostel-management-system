-- Hostel Management System — Sprint 1 schema
-- Modules covered: User Authentication, Student Management, Room Management

CREATE DATABASE IF NOT EXISTS hostel_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hostel_management;

-- Students (FR2)
CREATE TABLE IF NOT EXISTS students (
    student_id      INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    gender          VARCHAR(10)  NOT NULL,
    department      VARCHAR(50)  NOT NULL,
    year            INT          NOT NULL,
    mobile          VARCHAR(15)  NOT NULL,
    guardian_name   VARCHAR(100) NOT NULL,
    guardian_mobile VARCHAR(15)  NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Rooms (FR3)
CREATE TABLE IF NOT EXISTS rooms (
    room_id         INT AUTO_INCREMENT PRIMARY KEY,
    room_no         VARCHAR(10) NOT NULL UNIQUE,
    block           VARCHAR(20) NOT NULL,
    floor           VARCHAR(10) NOT NULL,
    capacity        INT NOT NULL,
    occupied_beds   INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Login accounts (FR1) — one account per admin/warden/student
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(50) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    role        ENUM('admin','warden','student') NOT NULL,
    full_name   VARCHAR(100) NOT NULL,
    student_id  INT NULL,
    status      ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Room allocation history — supports multi-bed rooms (FR3: allocate/vacate)
CREATE TABLE IF NOT EXISTS room_allocations (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    student_id      INT NOT NULL,
    room_id         INT NOT NULL,
    allocated_date  DATE NOT NULL,
    vacated_date    DATE NULL,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Handy view: a student can have at most one ACTIVE allocation (vacated_date IS NULL).
-- Enforced in application code (see admin_room_manage.php), not by a DB constraint,
-- since MySQL cannot express "unique where vacated_date IS NULL" directly.

-- ============================================================
-- Warden approval workflow addition — Student registration (FR1b)
-- If you already had this schema imported before this column existed,
-- this line adds it without touching any existing rows/data. Requires
-- MySQL 8.0.29+ / MariaDB 10.3+ for "ADD COLUMN IF NOT EXISTS"; on an
-- older server just drop "IF NOT EXISTS" and run it once.
-- ============================================================
ALTER TABLE users ADD COLUMN IF NOT EXISTS status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved' AFTER student_id;

-- ============================================================
-- Sprint 2 additions — Fees, Complaints, Notices
-- Safe to re-run this whole file on an existing database: every
-- statement above is IF NOT EXISTS, so nothing here touches your
-- existing students/rooms/users/room_allocations data.
-- ============================================================

-- Fee Management (FR4). A row is a single due/installment; "Pending"
-- until an admin records payment against it.
CREATE TABLE IF NOT EXISTS fees (
    fee_id      INT AUTO_INCREMENT PRIMARY KEY,
    student_id  INT NOT NULL,
    amount      DECIMAL(10,2) NOT NULL,
    due_date    DATE NOT NULL,
    paid_date   DATE NULL,
    mode        VARCHAR(20) NULL,
    status      ENUM('Pending','Paid') NOT NULL DEFAULT 'Pending',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Complaint Management (FR6). Students file; admin/warden triage.
CREATE TABLE IF NOT EXISTS complaints (
    complaint_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id   INT NOT NULL,
    subject      VARCHAR(150) NOT NULL,
    description  TEXT NOT NULL,
    status       ENUM('Pending','In Progress','Resolved') NOT NULL DEFAULT 'Pending',
    response     TEXT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at  TIMESTAMP NULL,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Notices — hostel-wide announcements, visible to every role.
CREATE TABLE IF NOT EXISTS notices (
    notice_id   INT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(150) NOT NULL,
    body        TEXT NOT NULL,
    posted_by   INT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (posted_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
