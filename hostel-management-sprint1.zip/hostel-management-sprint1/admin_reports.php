<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';
require_role('admin');

$type = $_GET['type'] ?? 'students';
if (!in_array($type, ['students', 'rooms', 'fees', 'complaints'], true)) {
    $type = 'students';
}

$pageTitle = 'Reports';
require 'includes/header.php';
?>

<?php hms_page_head('Reports', 'Student, occupancy, fee, and complaint reports at a glance'); ?>

<div class="hms-tabs">
  <a href="admin_reports.php?type=students" class="hms-tab<?= $type === 'students' ? ' is-active' : '' ?>"><?= icon('students') ?> Students</a>
  <a href="admin_reports.php?type=rooms" class="hms-tab<?= $type === 'rooms' ? ' is-active' : '' ?>"><?= icon('rooms') ?> Room Occupancy</a>
  <a href="admin_reports.php?type=fees" class="hms-tab<?= $type === 'fees' ? ' is-active' : '' ?>"><?= icon('wallet') ?> Fee Collection</a>
  <a href="admin_reports.php?type=complaints" class="hms-tab<?= $type === 'complaints' ? ' is-active' : '' ?>"><?= icon('complaints') ?> Complaints</a>
</div>

<?php if ($type === 'students'):
    $rows = $pdo->query('SELECT * FROM students ORDER BY name')->fetchAll();
?>
  <div class="hms-card" data-hms-table>
  <?php if (!$rows): ?>
    <?php hms_empty('students', 'No students yet'); ?>
  <?php else: ?>
    <div class="hms-table-toolbar">
      <div class="hms-table-search"><?= icon('search') ?><input type="text" data-hms-search placeholder="Search students"></div>
      <div class="hms-table-meta" data-hms-count></div>
    </div>
    <div class="table-responsive">
      <table class="table mb-0 align-middle">
        <thead><tr><th>ID</th><th>Name</th><th>Gender</th><th>Department</th><th>Year</th><th>Mobile</th></tr></thead>
        <tbody data-hms-rows>
          <?php foreach ($rows as $r): ?>
            <tr data-row>
              <td>#<?= (int) $r['student_id'] ?></td>
              <td><?= e($r['name']) ?></td>
              <td><?= e($r['gender']) ?></td>
              <td><?= e($r['department']) ?></td>
              <td><?= (int) $r['year'] ?></td>
              <td><?= e($r['mobile']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="hms-pagination" data-hms-pagination data-page-size="10"></div>
  <?php endif; ?>
  </div>

<?php elseif ($type === 'rooms'):
    $rows = $pdo->query('SELECT * FROM rooms ORDER BY block, room_no')->fetchAll();
    $totalCap = array_sum(array_column($rows, 'capacity'));
    $totalOcc = array_sum(array_column($rows, 'occupied_beds'));
?>
  <div class="hms-stat-grid hms-stat-grid-3">
    <?= hms_stat('Total Beds', (string) $totalCap, 'bed') ?>
    <?= hms_stat('Occupied', (string) $totalOcc, 'user-check', 'danger') ?>
    <?= hms_stat('Available', (string) ($totalCap - $totalOcc), 'door', 'success') ?>
  </div>
  <?php $occPct = $totalCap > 0 ? ($totalOcc / $totalCap) * 100 : 0; ?>
  <div class="hms-card hms-card-pad mb-3">
    <?= hms_progress('Overall bed occupancy', $occPct, round($occPct) . '% occupied', $occPct > 85 ? 'danger' : 'warning') ?>
  </div>
  <div class="hms-card" data-hms-table>
  <?php if (!$rows): ?>
    <?php hms_empty('building', 'No rooms yet'); ?>
  <?php else: ?>
    <div class="hms-table-toolbar">
      <div class="hms-table-search"><?= icon('search') ?><input type="text" data-hms-search placeholder="Search rooms"></div>
      <div class="hms-table-meta" data-hms-count></div>
    </div>
    <div class="table-responsive">
      <table class="table mb-0 align-middle">
        <thead><tr><th>Room</th><th>Block</th><th>Floor</th><th>Capacity</th><th>Occupied</th><th>Available</th></tr></thead>
        <tbody data-hms-rows>
          <?php foreach ($rows as $r): ?>
            <tr data-row>
              <td><span class="door-plate"><?= e($r['room_no']) ?></span></td>
              <td><?= e($r['block']) ?></td>
              <td><?= e($r['floor']) ?></td>
              <td><?= (int) $r['capacity'] ?></td>
              <td><?= (int) $r['occupied_beds'] ?></td>
              <td><?= (int) ($r['capacity'] - $r['occupied_beds']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="hms-pagination" data-hms-pagination data-page-size="10"></div>
  <?php endif; ?>
  </div>

<?php elseif ($type === 'fees'):
    $rows = $pdo->query(
        "SELECT f.*, s.name AS student_name FROM fees f JOIN students s ON s.student_id = f.student_id ORDER BY f.due_date DESC"
    )->fetchAll();
    $totals = $pdo->query(
        "SELECT COALESCE(SUM(CASE WHEN status='Paid' THEN amount ELSE 0 END),0) AS collected,
                COALESCE(SUM(CASE WHEN status='Pending' THEN amount ELSE 0 END),0) AS pending
         FROM fees"
    )->fetch();
?>
  <?php
  $feeTotal = (float) $totals['collected'] + (float) $totals['pending'];
  $collectedPct = $feeTotal > 0 ? ((float) $totals['collected'] / $feeTotal) * 100 : 0;
  ?>
  <div class="hms-grid-7-5" style="align-items:stretch;">
    <div class="hms-stat-grid hms-stat-grid-2" style="align-content:start;">
      <?= hms_stat('Collected', '&#8377;' . number_format((float) $totals['collected']), 'wallet', 'success') ?>
      <?= hms_stat('Pending', '&#8377;' . number_format((float) $totals['pending']), 'wallet', 'danger') ?>
    </div>
    <div class="hms-card hms-card-pad d-flex align-items-center justify-content-center">
      <?= hms_donut($collectedPct, round($collectedPct) . '%', 'Collected', 'success') ?>
    </div>
  </div>
  <div class="hms-card" data-hms-table>
  <?php if (!$rows): ?>
    <?php hms_empty('wallet', 'No fee records yet'); ?>
  <?php else: ?>
    <div class="hms-table-toolbar">
      <div class="hms-table-search"><?= icon('search') ?><input type="text" data-hms-search placeholder="Search by student"></div>
      <div class="hms-table-meta" data-hms-count></div>
    </div>
    <div class="table-responsive">
      <table class="table mb-0 align-middle">
        <thead><tr><th>Student</th><th>Amount</th><th>Due Date</th><th>Status</th><th>Paid Date</th><th>Mode</th></tr></thead>
        <tbody data-hms-rows>
          <?php foreach ($rows as $r): ?>
            <tr data-row>
              <td><?= e($r['student_name']) ?></td>
              <td>&#8377;<?= number_format((float) $r['amount']) ?></td>
              <td><?= e($r['due_date']) ?></td>
              <td><?= hms_status_badge($r['status']) ?></td>
              <td><?= e($r['paid_date'] ?? '&mdash;') ?></td>
              <td><?= e($r['mode'] ?? '&mdash;') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="hms-pagination" data-hms-pagination data-page-size="10"></div>
  <?php endif; ?>
  </div>

<?php elseif ($type === 'complaints'):
    $rows = $pdo->query(
        "SELECT c.*, s.name AS student_name FROM complaints c JOIN students s ON s.student_id = c.student_id ORDER BY c.created_at DESC"
    )->fetchAll();
    $counts = $pdo->query("SELECT status, COUNT(*) c FROM complaints GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
?>
  <?php
  $totalComplaints = array_sum($counts);
  $resolvedPct = $totalComplaints > 0 ? (((int) ($counts['Resolved'] ?? 0)) / $totalComplaints) * 100 : 0;
  ?>
  <div class="hms-grid-7-5" style="align-items:stretch;">
    <div class="hms-stat-grid hms-stat-grid-3" style="align-content:start;">
      <?= hms_stat('Pending', (string) (int) ($counts['Pending'] ?? 0), 'alert', 'danger') ?>
      <?= hms_stat('In Progress', (string) (int) ($counts['In Progress'] ?? 0), 'activity', 'warning') ?>
      <?= hms_stat('Resolved', (string) (int) ($counts['Resolved'] ?? 0), 'check-circle', 'success') ?>
    </div>
    <div class="hms-card hms-card-pad d-flex align-items-center justify-content-center">
      <?= hms_donut($resolvedPct, round($resolvedPct) . '%', 'Resolved', 'success') ?>
    </div>
  </div>
  <div class="hms-card" data-hms-table>
  <?php if (!$rows): ?>
    <?php hms_empty('complaints', 'No complaints yet'); ?>
  <?php else: ?>
    <div class="hms-table-toolbar">
      <div class="hms-table-search"><?= icon('search') ?><input type="text" data-hms-search placeholder="Search by student or subject"></div>
      <div class="hms-table-meta" data-hms-count></div>
    </div>
    <div class="table-responsive">
      <table class="table mb-0 align-middle">
        <thead><tr><th>Student</th><th>Subject</th><th>Status</th><th>Filed</th></tr></thead>
        <tbody data-hms-rows>
          <?php foreach ($rows as $r): ?>
            <tr data-row>
              <td><?= e($r['student_name']) ?></td>
              <td><?= e($r['subject']) ?></td>
              <td><?= hms_status_badge($r['status']) ?></td>
              <td><?= e($r['created_at']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="hms-pagination" data-hms-pagination data-page-size="10"></div>
  <?php endif; ?>
  </div>
<?php endif; ?>

<?php require 'includes/footer.php'; ?>
