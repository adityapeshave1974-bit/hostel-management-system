<?php
// Database connection settings.
// Defaults match a fresh XAMPP install. Change these if your setup differs.
define('DB_HOST', 'localhost');
define('DB_NAME', 'hostel_management');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // In production, log this instead of showing it to the user.
    die("Database connection failed. Please check config/database.php and confirm the "
        . "'hostel_management' database has been imported. (" . $e->getMessage() . ")");
}
