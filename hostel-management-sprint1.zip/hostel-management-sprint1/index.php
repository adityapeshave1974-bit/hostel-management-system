<?php
require 'config/database.php';
require 'includes/functions.php';
require 'includes/auth.php';

redirect(is_logged_in() ? 'dashboard.php' : 'login.php');
